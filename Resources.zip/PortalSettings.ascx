<%@ Control Language="C#" AutoEventWireup="true" Inherits="DotNetNuke.Entities.Modules.PortalModuleBase" %>
<%@ Import Namespace="System" %>
<%@ Import Namespace="System.Collections.Generic" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Import Namespace="System.Text" %>
<%@ Import Namespace="System.Security.Cryptography" %>
<%@ Import Namespace="DotNetNuke.Common.Utilities" %>
<%@ Import Namespace="DotNetNuke.Data" %>
<%@ Import Namespace="DotNetNuke.Services.Exceptions" %>

<script runat="server">
    private const int MaximumBlockedTermsSettingLength = 8000;
    private const int MaximumBlockedTermCount = 250;
    private const int MaximumBlockedTermLength = 100;
    private const int MaximumNotificationAddressLength = 2000;
    private const int PendingCommentsPageSize = 25;
    private const string SecurityTokenSessionKeyPrefix = "JacarandaComments_PortalSettingsSecurityToken_";

    private string ConnectionString
    {
        get { return Config.GetConnectionString(); }
    }

    private string PortalSettingsTable
    {
        get
        {
            var provider = DataProvider.Instance();
            var owner = CleanSqlIdentifierPart(provider.DatabaseOwner, "dbo");
            var qualifier = CleanSqlIdentifierPart(provider.ObjectQualifier, String.Empty);
            return "[" + owner + "].[" + qualifier + "JacarandaCommentsPortalSettings]";
        }
    }

    private string CommentsTable
    {
        get { return GetDnnTableName("JacarandaComments"); }
    }

    private string TabsTable
    {
        get { return GetDnnTableName("Tabs"); }
    }

    private string TabModulesTable
    {
        get { return GetDnnTableName("TabModules"); }
    }

    private int PendingCommentsPageIndex
    {
        get
        {
            var value = ViewState["JacarandaCommentsPendingPageIndex"];
            var pageIndex = value == null ? 0 : Convert.ToInt32(value);
            return pageIndex < 0 ? 0 : pageIndex;
        }
        set { ViewState["JacarandaCommentsPendingPageIndex"] = value < 0 ? 0 : value; }
    }

    private string SecurityTokenSessionKey
    {
        get { return SecurityTokenSessionKeyPrefix + PortalId + "_" + ModuleId + "_" + UserId; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!CanManagePortalSettings())
            {
                Response.StatusCode = 403;
                pnlAccessDenied.Visible = true;
                pnlPortalSettings.Visible = false;
                return;
            }

            pnlAccessDenied.Visible = false;
            pnlPortalSettings.Visible = true;

            if (!IsPostBack)
            {
                EnsureSecurityToken();
                LoadPendingComments();
                LoadPortalSettings();
            }
        }
        catch (Exception ex)
        {
            Exceptions.ProcessModuleLoadException(this, ex);
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (!CanManagePortalSettings())
            {
                Response.StatusCode = 403;
                ShowMessage("You are not authorised to change site-wide Jacaranda Comments settings.", false);
                return;
            }

            if (!ValidateSecurityToken())
            {
                ShowMessage("For your safety, please refresh the page and try again.", false);
                return;
            }

            Page.Validate("PortalSettings");
            if (!Page.IsValid)
            {
                ShowMessage("Please correct the highlighted settings before saving.", false);
                return;
            }

            SavePortalSettings();
            var centralActive = IsCentralSettingsActive();
            EnsureSecurityToken(true);
            LoadPendingComments();
            LoadPortalSettings();
            ShowMessage(
                centralActive
                    ? "Central Jacaranda Comments settings have been saved."
                    : "Settings have been saved for review. Existing module settings remain active until central configuration is activated.",
                true);
        }
        catch (Exception ex)
        {
            Exceptions.ProcessModuleLoadException(this, ex);
        }
    }

    protected void btnActivateCentral_Click(object sender, EventArgs e)
    {
        try
        {
            if (!CanManagePortalSettings())
            {
                Response.StatusCode = 403;
                ShowMessage("You are not authorised to activate central Jacaranda Comments settings.", false);
                return;
            }

            if (!ValidateSecurityToken())
            {
                ShowMessage("For your safety, please refresh the page and try again.", false);
                return;
            }

            Page.Validate("PortalSettings");
            if (!Page.IsValid)
            {
                ShowMessage("Please correct the highlighted settings before activating central configuration.", false);
                return;
            }

            SavePortalSettings();
            ActivateCentralSettings();

            EnsureSecurityToken(true);
            LoadPendingComments();
            LoadPortalSettings();
            ShowMessage("Central configuration is now active. Every Jacaranda Comments Advanced instance in this portal uses the settings in Comments Administration.", true);
        }
        catch (Exception ex)
        {
            Exceptions.ProcessModuleLoadException(this, ex);
        }
    }

    protected void rptPendingComments_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
    {
        try
        {
            if (!CanManagePortalSettings())
            {
                Response.StatusCode = 403;
                ShowMessage("You are not authorised to moderate comments across this portal.", false);
                return;
            }

            if (!ValidateSecurityToken())
            {
                ShowMessage("For your safety, please refresh the page and try again.", false);
                return;
            }

            int commentId;
            if (!Int32.TryParse(Convert.ToString(e.CommandArgument), out commentId) || commentId <= 0)
            {
                ShowMessage("The selected comment could not be identified.", false);
                LoadPendingComments();
                return;
            }

            if (String.Equals(e.CommandName, "ApprovePending", StringComparison.OrdinalIgnoreCase))
            {
                if (ApprovePendingComment(commentId))
                {
                    ShowMessage("The submission has been approved.", true);
                }
                else
                {
                    ShowMessage("The comment was not changed. It may already have been moderated or deleted.", false);
                }
            }
            else if (String.Equals(e.CommandName, "DeletePending", StringComparison.OrdinalIgnoreCase))
            {
                if (SoftDeletePendingCommentTree(commentId))
                {
                    ShowMessage("The submission has been rejected and removed from view.", true);
                }
                else
                {
                    ShowMessage("The comment was not changed. It may already have been moderated or deleted.", false);
                }
            }

            LoadPendingComments();
        }
        catch (Exception ex)
        {
            Exceptions.ProcessModuleLoadException(this, ex);
        }
    }

    protected void btnPendingPrevious_Click(object sender, EventArgs e)
    {
        if (!CanManagePortalSettings())
        {
            Response.StatusCode = 403;
            return;
        }

        PendingCommentsPageIndex = Math.Max(0, PendingCommentsPageIndex - 1);
        LoadPendingComments();
    }

    protected void btnPendingNext_Click(object sender, EventArgs e)
    {
        if (!CanManagePortalSettings())
        {
            Response.StatusCode = 403;
            return;
        }

        PendingCommentsPageIndex = PendingCommentsPageIndex + 1;
        LoadPendingComments();
    }

    private void LoadPendingComments()
    {
        var totalCount = 0;
        var pageIndex = PendingCommentsPageIndex;
        var table = new DataTable();

        using (var connection = new SqlConnection(ConnectionString))
        {
            connection.Open();

            using (var countCommand = connection.CreateCommand())
            {
                countCommand.CommandText = @"
SELECT COUNT(*)
FROM " + CommentsTable + @"
WHERE PortalId = @PortalId
  AND IsApproved = 0
  AND IsDeleted = 0;";
                countCommand.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
                totalCount = Convert.ToInt32(countCommand.ExecuteScalar());
            }

            var totalPages = totalCount == 0
                ? 0
                : (int)Math.Ceiling(totalCount / (double)PendingCommentsPageSize);

            if (totalPages > 0 && pageIndex >= totalPages)
            {
                pageIndex = totalPages - 1;
                PendingCommentsPageIndex = pageIndex;
            }
            else if (totalPages == 0)
            {
                pageIndex = 0;
                PendingCommentsPageIndex = 0;
            }

            if (totalCount > 0)
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = @"
SELECT c.CommentId,
       c.TabId,
       c.ModuleId,
       c.ParentCommentId,
       c.UserId,
       c.DisplayName,
       c.CommentText,
       c.IsLanguageFlagged,
       c.CreatedOnDate,
       t.TabName AS PageTitle,
       tm.ModuleTitle
FROM " + CommentsTable + @" c
LEFT JOIN " + TabsTable + @" t
       ON t.TabID = c.TabId
      AND t.PortalID = c.PortalId
LEFT JOIN " + TabModulesTable + @" tm
       ON tm.TabID = c.TabId
      AND tm.ModuleID = c.ModuleId
WHERE c.PortalId = @PortalId
  AND c.IsApproved = 0
  AND c.IsDeleted = 0
ORDER BY c.CreatedOnDate DESC, c.CommentId DESC
OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;";
                    command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
                    command.Parameters.Add("@Offset", SqlDbType.Int).Value = pageIndex * PendingCommentsPageSize;
                    command.Parameters.Add("@PageSize", SqlDbType.Int).Value = PendingCommentsPageSize;

                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
        }

        rptPendingComments.DataSource = table;
        rptPendingComments.DataBind();
        pnlNoPendingComments.Visible = totalCount == 0;

        litPendingSummary.Text = totalCount == 1
            ? "1 comment is waiting for approval across this portal."
            : totalCount.ToString() + " comments are waiting for approval across this portal.";

        var pageCount = totalCount == 0
            ? 0
            : (int)Math.Ceiling(totalCount / (double)PendingCommentsPageSize);
        pnlPendingPager.Visible = pageCount > 1;
        btnPendingPrevious.Enabled = pageIndex > 0;
        btnPendingNext.Enabled = pageCount > 0 && pageIndex < pageCount - 1;
        litPendingPage.Text = pageCount > 0
            ? "Page " + (pageIndex + 1).ToString() + " of " + pageCount.ToString()
            : String.Empty;
    }

    private bool ApprovePendingComment(int commentId)
    {
        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
UPDATE " + CommentsTable + @"
SET IsApproved = 1,
    GuestEditTokenHash = NULL,
    LastModifiedOnDate = GETUTCDATE(),
    LastModifiedByUserId = @UserId
WHERE CommentId = @CommentId
  AND PortalId = @PortalId
  AND IsApproved = 0
  AND IsDeleted = 0;";
            command.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
            command.Parameters.Add("@CommentId", SqlDbType.Int).Value = commentId;
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            connection.Open();
            return command.ExecuteNonQuery() == 1;
        }
    }

    private bool SoftDeletePendingCommentTree(int commentId)
    {
        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
;WITH CommentTree AS
(
    SELECT CommentId
    FROM " + CommentsTable + @"
    WHERE CommentId = @CommentId
      AND PortalId = @PortalId
      AND IsDeleted = 0

    UNION ALL

    SELECT child.CommentId
    FROM " + CommentsTable + @" child
    INNER JOIN CommentTree parentComment
            ON child.ParentCommentId = parentComment.CommentId
    WHERE child.PortalId = @PortalId
      AND child.IsDeleted = 0
)
UPDATE target
SET IsDeleted = 1,
    GuestEditTokenHash = NULL,
    LastModifiedOnDate = GETUTCDATE(),
    LastModifiedByUserId = @UserId
FROM " + CommentsTable + @" target
INNER JOIN CommentTree tree
        ON tree.CommentId = target.CommentId
OPTION (MAXRECURSION 100);";
            command.Parameters.Add("@CommentId", SqlDbType.Int).Value = commentId;
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
            connection.Open();
            return command.ExecuteNonQuery() > 0;
        }
    }

    protected string PendingPageTitle(object pageTitle, object tabId)
    {
        var value = Convert.ToString(pageTitle);
        if (!String.IsNullOrWhiteSpace(value)) return Server.HtmlEncode(value.Trim());
        return "Page " + Server.HtmlEncode(Convert.ToString(tabId));
    }

    protected string PendingModuleTitle(object moduleTitle, object moduleId)
    {
        var value = Convert.ToString(moduleTitle);
        if (!String.IsNullOrWhiteSpace(value)) return Server.HtmlEncode(value.Trim());
        return "Module " + Server.HtmlEncode(Convert.ToString(moduleId));
    }

    protected string PendingSubmissionType(object parentCommentId)
    {
        return parentCommentId == null || parentCommentId == DBNull.Value
            ? "Comment"
            : "Reply";
    }

    protected string PendingAuthorType(object userId)
    {
        return userId == null || userId == DBNull.Value ? "Guest" : "Registered user";
    }

    protected string PendingCommentBody(object value)
    {
        var encoded = Server.HtmlEncode(Convert.ToString(value) ?? String.Empty);
        return encoded.Replace("\r\n", "<br />").Replace("\n", "<br />").Replace("\r", "<br />");
    }

    protected string PendingCreatedDate(object value)
    {
        if (value == null || value == DBNull.Value) return String.Empty;
        return Server.HtmlEncode(FormatUtc(Convert.ToDateTime(value)));
    }

    protected bool PendingLanguageFlagVisible(object value)
    {
        return value != null && value != DBNull.Value && Convert.ToBoolean(value);
    }

    protected string PendingViewUrl(object tabId, object moduleId, object commentId)
    {
        int parsedTabId;
        int parsedModuleId;
        int parsedCommentId;
        if (!Int32.TryParse(Convert.ToString(tabId), out parsedTabId) || parsedTabId <= 0) return String.Empty;
        if (!Int32.TryParse(Convert.ToString(moduleId), out parsedModuleId) || parsedModuleId <= 0) return String.Empty;
        if (!Int32.TryParse(Convert.ToString(commentId), out parsedCommentId) || parsedCommentId <= 0) return String.Empty;

        return DotNetNuke.Common.Globals.NavigateURL(parsedTabId, String.Empty)
            + "#jacaranda-comment-" + parsedModuleId.ToString() + "-" + parsedCommentId.ToString();
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect(DotNetNuke.Common.Globals.NavigateURL(TabId), false);
        Context.ApplicationInstance.CompleteRequest();
    }

    private bool CanManagePortalSettings()
    {
        if (UserInfo == null)
        {
            return false;
        }

        if (UserInfo.IsSuperUser)
        {
            return true;
        }

        var administratorRoleName = PortalSettings == null
            ? String.Empty
            : (PortalSettings.AdministratorRoleName ?? String.Empty).Trim();

        return !String.IsNullOrWhiteSpace(administratorRoleName)
            && UserInfo.IsInRole(administratorRoleName);
    }

    private void LoadPortalSettings()
    {
        var settings = ReadPortalSettings();

        chkPostingEnabled.Checked = settings.PostingEnabled;
        chkGuestPostingEnabled.Checked = settings.GuestPostingEnabled;
        chkDefaultAllowGuestComments.Checked = settings.DefaultAllowGuestComments;
        chkDefaultRequireApproval.Checked = settings.DefaultRequireApprovalForNonEditors;
        chkDefaultEnableLanguageFilter.Checked = settings.DefaultEnableLanguageFilter;
        txtDefaultBlockedLanguageTerms.Text = settings.DefaultBlockedLanguageTerms;
        txtDefaultMaximumCommentLength.Text = settings.DefaultMaximumCommentLength.ToString();
        chkDefaultEnableRateLimiting.Checked = settings.DefaultEnableRateLimiting;
        txtDefaultRateLimitSeconds.Text = settings.DefaultRateLimitSeconds.ToString();
        txtDefaultRateLimitMaxPosts.Text = settings.DefaultRateLimitMaxPosts.ToString();
        txtDefaultRateLimitWindowMinutes.Text = settings.DefaultRateLimitWindowMinutes.ToString();
        chkDefaultEnableCaptcha.Checked = settings.DefaultEnableCaptcha;
        chkDefaultEnableNotifications.Checked = settings.DefaultEnableNotifications;
        txtDefaultNotificationEmailAddresses.Text = settings.DefaultNotificationEmailAddresses;
        chkDefaultIncludeCommentTextInNotifications.Checked = settings.DefaultIncludeCommentTextInNotifications;

        pnlCentralMigration.Visible = !settings.CentralSettingsActive;
        pnlCentralActive.Visible = settings.CentralSettingsActive;
        btnActivateCentral.Visible = !settings.CentralSettingsActive;
        btnSave.Text = settings.CentralSettingsActive ? "Save comment settings" : "Save settings for review";

        if (settings.ModifiedOnDate.HasValue)
        {
            litAudit.Text = "Last changed "
                + Server.HtmlEncode(FormatUtc(settings.ModifiedOnDate.Value))
                + " by DNN user ID "
                + settings.ModifiedByUserId.ToString()
                + ".";
        }
        else
        {
            litAudit.Text = "No site-wide settings have been saved yet. Built-in safe defaults are currently in use.";
        }
    }

    private PortalCommentSettings ReadPortalSettings()
    {
        var settings = PortalCommentSettings.CreateDefaults();

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
SELECT PostingEnabled,
       GuestPostingEnabled,
       CentralSettingsActive,
       DefaultAllowGuestComments,
       DefaultRequireApprovalForNonEditors,
       DefaultEnableLanguageFilter,
       DefaultBlockedLanguageTerms,
       DefaultMaximumCommentLength,
       DefaultEnableRateLimiting,
       DefaultRateLimitSeconds,
       DefaultRateLimitMaxPosts,
       DefaultRateLimitWindowMinutes,
       DefaultEnableCaptcha,
       DefaultEnableNotifications,
       DefaultNotificationEmailAddresses,
       DefaultIncludeCommentTextInNotifications,
       ModifiedOnDate,
       ModifiedByUserId
FROM " + PortalSettingsTable + @"
WHERE PortalId = @PortalId;";

            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            connection.Open();

            using (var reader = command.ExecuteReader(CommandBehavior.SingleRow))
            {
                if (!reader.Read())
                {
                    return settings;
                }

                settings.PostingEnabled = ReadBool(reader, "PostingEnabled", true);
                settings.GuestPostingEnabled = ReadBool(reader, "GuestPostingEnabled", true);
                settings.CentralSettingsActive = ReadBool(reader, "CentralSettingsActive", false);
                settings.DefaultAllowGuestComments = ReadBool(reader, "DefaultAllowGuestComments", false);
                settings.DefaultRequireApprovalForNonEditors = ReadBool(reader, "DefaultRequireApprovalForNonEditors", true);
                settings.DefaultEnableLanguageFilter = ReadBool(reader, "DefaultEnableLanguageFilter", false);
                settings.DefaultBlockedLanguageTerms = ReadString(reader, "DefaultBlockedLanguageTerms", String.Empty);
                settings.DefaultMaximumCommentLength = ClampInt(ReadInt(reader, "DefaultMaximumCommentLength", 4000), 4000, 250, 10000);
                settings.DefaultEnableRateLimiting = ReadBool(reader, "DefaultEnableRateLimiting", true);
                settings.DefaultRateLimitSeconds = ClampInt(ReadInt(reader, "DefaultRateLimitSeconds", 60), 60, 0, 3600);
                settings.DefaultRateLimitMaxPosts = ClampInt(ReadInt(reader, "DefaultRateLimitMaxPosts", 5), 5, 1, 100);
                settings.DefaultRateLimitWindowMinutes = ClampInt(ReadInt(reader, "DefaultRateLimitWindowMinutes", 15), 15, 1, 1440);
                settings.DefaultEnableCaptcha = ReadBool(reader, "DefaultEnableCaptcha", false);
                settings.DefaultEnableNotifications = ReadBool(reader, "DefaultEnableNotifications", false);
                settings.DefaultNotificationEmailAddresses = ReadString(reader, "DefaultNotificationEmailAddresses", String.Empty);
                settings.DefaultIncludeCommentTextInNotifications = ReadBool(reader, "DefaultIncludeCommentTextInNotifications", true);
                settings.ModifiedOnDate = ReadNullableDateTime(reader, "ModifiedOnDate");
                settings.ModifiedByUserId = ReadInt(reader, "ModifiedByUserId", -1);
            }
        }

        return settings;
    }

    private void SavePortalSettings()
    {
        var blockedTerms = NormalizeBlockedTermsSetting(txtDefaultBlockedLanguageTerms.Text);
        var notificationAddresses = Truncate((txtDefaultNotificationEmailAddresses.Text ?? String.Empty).Trim(), MaximumNotificationAddressLength);
        var maximumCommentLength = ClampInt(txtDefaultMaximumCommentLength.Text, 4000, 250, 10000);
        var rateLimitSeconds = ClampInt(txtDefaultRateLimitSeconds.Text, 60, 0, 3600);
        var rateLimitMaxPosts = ClampInt(txtDefaultRateLimitMaxPosts.Text, 5, 1, 100);
        var rateLimitWindowMinutes = ClampInt(txtDefaultRateLimitWindowMinutes.Text, 15, 1, 1440);

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
IF EXISTS (SELECT 1 FROM " + PortalSettingsTable + @" WHERE PortalId = @PortalId)
BEGIN
    UPDATE " + PortalSettingsTable + @"
    SET PostingEnabled = @PostingEnabled,
        GuestPostingEnabled = @GuestPostingEnabled,
        DefaultAllowGuestComments = @DefaultAllowGuestComments,
        DefaultRequireApprovalForNonEditors = @DefaultRequireApprovalForNonEditors,
        DefaultEnableLanguageFilter = @DefaultEnableLanguageFilter,
        DefaultBlockedLanguageTerms = @DefaultBlockedLanguageTerms,
        DefaultMaximumCommentLength = @DefaultMaximumCommentLength,
        DefaultEnableRateLimiting = @DefaultEnableRateLimiting,
        DefaultRateLimitSeconds = @DefaultRateLimitSeconds,
        DefaultRateLimitMaxPosts = @DefaultRateLimitMaxPosts,
        DefaultRateLimitWindowMinutes = @DefaultRateLimitWindowMinutes,
        DefaultEnableCaptcha = @DefaultEnableCaptcha,
        DefaultEnableNotifications = @DefaultEnableNotifications,
        DefaultNotificationEmailAddresses = @DefaultNotificationEmailAddresses,
        DefaultIncludeCommentTextInNotifications = @DefaultIncludeCommentTextInNotifications,
        ModifiedOnDate = GETUTCDATE(),
        ModifiedByUserId = @ModifiedByUserId
    WHERE PortalId = @PortalId;
END
ELSE
BEGIN
    INSERT INTO " + PortalSettingsTable + @" (
        PortalId,
        PostingEnabled,
        GuestPostingEnabled,
        CentralSettingsActive,
        DefaultAllowGuestComments,
        DefaultRequireApprovalForNonEditors,
        DefaultEnableLanguageFilter,
        DefaultBlockedLanguageTerms,
        DefaultMaximumCommentLength,
        DefaultEnableRateLimiting,
        DefaultRateLimitSeconds,
        DefaultRateLimitMaxPosts,
        DefaultRateLimitWindowMinutes,
        DefaultEnableCaptcha,
        DefaultEnableNotifications,
        DefaultNotificationEmailAddresses,
        DefaultIncludeCommentTextInNotifications,
        ModifiedOnDate,
        ModifiedByUserId
    )
    VALUES (
        @PortalId,
        @PostingEnabled,
        @GuestPostingEnabled,
        0,
        @DefaultAllowGuestComments,
        @DefaultRequireApprovalForNonEditors,
        @DefaultEnableLanguageFilter,
        @DefaultBlockedLanguageTerms,
        @DefaultMaximumCommentLength,
        @DefaultEnableRateLimiting,
        @DefaultRateLimitSeconds,
        @DefaultRateLimitMaxPosts,
        @DefaultRateLimitWindowMinutes,
        @DefaultEnableCaptcha,
        @DefaultEnableNotifications,
        @DefaultNotificationEmailAddresses,
        @DefaultIncludeCommentTextInNotifications,
        GETUTCDATE(),
        @ModifiedByUserId
    );
END";

            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@PostingEnabled", SqlDbType.Bit).Value = chkPostingEnabled.Checked;
            command.Parameters.Add("@GuestPostingEnabled", SqlDbType.Bit).Value = chkGuestPostingEnabled.Checked;
            command.Parameters.Add("@DefaultAllowGuestComments", SqlDbType.Bit).Value = chkDefaultAllowGuestComments.Checked;
            command.Parameters.Add("@DefaultRequireApprovalForNonEditors", SqlDbType.Bit).Value = chkDefaultRequireApproval.Checked;
            command.Parameters.Add("@DefaultEnableLanguageFilter", SqlDbType.Bit).Value = chkDefaultEnableLanguageFilter.Checked;
            command.Parameters.Add("@DefaultBlockedLanguageTerms", SqlDbType.NVarChar, -1).Value = blockedTerms;
            command.Parameters.Add("@DefaultMaximumCommentLength", SqlDbType.Int).Value = maximumCommentLength;
            command.Parameters.Add("@DefaultEnableRateLimiting", SqlDbType.Bit).Value = chkDefaultEnableRateLimiting.Checked;
            command.Parameters.Add("@DefaultRateLimitSeconds", SqlDbType.Int).Value = rateLimitSeconds;
            command.Parameters.Add("@DefaultRateLimitMaxPosts", SqlDbType.Int).Value = rateLimitMaxPosts;
            command.Parameters.Add("@DefaultRateLimitWindowMinutes", SqlDbType.Int).Value = rateLimitWindowMinutes;
            command.Parameters.Add("@DefaultEnableCaptcha", SqlDbType.Bit).Value = chkDefaultEnableCaptcha.Checked;
            command.Parameters.Add("@DefaultEnableNotifications", SqlDbType.Bit).Value = chkDefaultEnableNotifications.Checked;
            command.Parameters.Add("@DefaultNotificationEmailAddresses", SqlDbType.NVarChar, MaximumNotificationAddressLength).Value = notificationAddresses;
            command.Parameters.Add("@DefaultIncludeCommentTextInNotifications", SqlDbType.Bit).Value = chkDefaultIncludeCommentTextInNotifications.Checked;
            command.Parameters.Add("@ModifiedByUserId", SqlDbType.Int).Value = UserId;

            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    private void ActivateCentralSettings()
    {
        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
UPDATE " + PortalSettingsTable + @"
SET CentralSettingsActive = 1,
    ModifiedOnDate = GETUTCDATE(),
    ModifiedByUserId = @ModifiedByUserId
WHERE PortalId = @PortalId
  AND CentralSettingsActive = 0;";
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@ModifiedByUserId", SqlDbType.Int).Value = UserId;
            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    private bool IsCentralSettingsActive()
    {
        return ReadPortalSettings().CentralSettingsActive;
    }

    private void EnsureSecurityToken()
    {
        EnsureSecurityToken(false);
    }

    private void EnsureSecurityToken(bool rotate)
    {
        if (Session == null || hdnSecurityToken == null)
        {
            return;
        }

        var token = rotate ? String.Empty : Convert.ToString(Session[SecurityTokenSessionKey]);

        if (String.IsNullOrWhiteSpace(token))
        {
            token = GenerateSecurityToken();
            Session[SecurityTokenSessionKey] = token;
        }

        hdnSecurityToken.Value = token;
    }

    private bool ValidateSecurityToken()
    {
        if (Session == null || hdnSecurityToken == null)
        {
            return false;
        }

        return SecureEquals(Convert.ToString(Session[SecurityTokenSessionKey]), hdnSecurityToken.Value);
    }

    private static string GenerateSecurityToken()
    {
        var bytes = new byte[32];
        using (var rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(bytes);
        }
        return Convert.ToBase64String(bytes);
    }

    private static bool SecureEquals(string expected, string supplied)
    {
        if (String.IsNullOrEmpty(expected) || String.IsNullOrEmpty(supplied))
        {
            return false;
        }

        var expectedBytes = Encoding.UTF8.GetBytes(expected);
        var suppliedBytes = Encoding.UTF8.GetBytes(supplied);
        var diff = expectedBytes.Length ^ suppliedBytes.Length;
        var length = Math.Min(expectedBytes.Length, suppliedBytes.Length);

        for (var i = 0; i < length; i++)
        {
            diff |= expectedBytes[i] ^ suppliedBytes[i];
        }

        return diff == 0;
    }

    private void ShowMessage(string message, bool success)
    {
        pnlMessage.Visible = true;
        pnlMessage.CssClass = success ? "jc-message jc-message-success" : "jc-message jc-message-error";
        litMessage.Text = Server.HtmlEncode(message ?? String.Empty);
    }

    private string NormalizeBlockedTermsSetting(string raw)
    {
        raw = raw ?? String.Empty;
        if (raw.Length > MaximumBlockedTermsSettingLength)
        {
            raw = raw.Substring(0, MaximumBlockedTermsSettingLength);
        }

        var terms = new List<string>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var lines = raw.Replace("\r\n", "\n").Replace('\r', '\n')
            .Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

        foreach (var line in lines)
        {
            var term = RemoveControlCharacters((line ?? String.Empty).Trim());
            if (String.IsNullOrWhiteSpace(term)) continue;
            if (term.Length > MaximumBlockedTermLength) term = term.Substring(0, MaximumBlockedTermLength).Trim();
            if (term.Length == 0 || !seen.Add(term)) continue;
            terms.Add(term);
            if (terms.Count >= MaximumBlockedTermCount) break;
        }

        return String.Join(Environment.NewLine, terms.ToArray());
    }

    private static string RemoveControlCharacters(string value)
    {
        if (String.IsNullOrEmpty(value)) return String.Empty;
        var characters = new List<char>(value.Length);
        foreach (var character in value)
        {
            if (!Char.IsControl(character)) characters.Add(character);
        }
        return new String(characters.ToArray());
    }

    private static int ClampInt(string raw, int defaultValue, int minValue, int maxValue)
    {
        int value;
        if (!Int32.TryParse((raw ?? String.Empty).Trim(), out value)) value = defaultValue;
        return ClampInt(value, defaultValue, minValue, maxValue);
    }

    private static int ClampInt(int value, int defaultValue, int minValue, int maxValue)
    {
        if (value < minValue) value = minValue;
        if (value > maxValue) value = maxValue;
        return value;
    }

    private static string Truncate(string value, int maximumLength)
    {
        value = value ?? String.Empty;
        return value.Length <= maximumLength ? value : value.Substring(0, maximumLength);
    }

    private static bool ReadBool(IDataRecord record, string name, bool defaultValue)
    {
        var ordinal = record.GetOrdinal(name);
        return record.IsDBNull(ordinal) ? defaultValue : Convert.ToBoolean(record.GetValue(ordinal));
    }

    private static int ReadInt(IDataRecord record, string name, int defaultValue)
    {
        var ordinal = record.GetOrdinal(name);
        return record.IsDBNull(ordinal) ? defaultValue : Convert.ToInt32(record.GetValue(ordinal));
    }

    private static string ReadString(IDataRecord record, string name, string defaultValue)
    {
        var ordinal = record.GetOrdinal(name);
        return record.IsDBNull(ordinal) ? defaultValue : Convert.ToString(record.GetValue(ordinal));
    }

    private static DateTime? ReadNullableDateTime(IDataRecord record, string name)
    {
        var ordinal = record.GetOrdinal(name);
        return record.IsDBNull(ordinal) ? (DateTime?)null : Convert.ToDateTime(record.GetValue(ordinal));
    }

    private static string FormatUtc(DateTime value)
    {
        return DateTime.SpecifyKind(value, DateTimeKind.Utc).ToString("dd MMM yyyy, h:mm tt") + " UTC";
    }

    private string GetDnnTableName(string tableName)
    {
        var provider = DataProvider.Instance();
        var owner = CleanSqlIdentifierPart(provider.DatabaseOwner, "dbo");
        var qualifier = CleanSqlIdentifierPart(provider.ObjectQualifier, String.Empty);
        var cleanTableName = CleanSqlIdentifierPart(tableName, String.Empty);
        if (String.IsNullOrEmpty(cleanTableName))
        {
            throw new InvalidOperationException("A valid DNN table name is required.");
        }
        return "[" + owner + "].[" + qualifier + cleanTableName + "]";
    }

    private static string CleanSqlIdentifierPart(string value, string defaultValue)
    {
        value = (value ?? String.Empty).Trim();
        if (value.EndsWith(".", StringComparison.Ordinal)) value = value.Substring(0, value.Length - 1);
        value = value.Replace("[", String.Empty).Replace("]", String.Empty).Trim();
        if (String.IsNullOrEmpty(value)) return defaultValue ?? String.Empty;

        for (var i = 0; i < value.Length; i++)
        {
            var c = value[i];
            if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_'))
            {
                return defaultValue ?? String.Empty;
            }
        }

        return value;
    }

    private sealed class PortalCommentSettings
    {
        public bool PostingEnabled { get; set; }
        public bool GuestPostingEnabled { get; set; }
        public bool CentralSettingsActive { get; set; }
        public bool DefaultAllowGuestComments { get; set; }
        public bool DefaultRequireApprovalForNonEditors { get; set; }
        public bool DefaultEnableLanguageFilter { get; set; }
        public string DefaultBlockedLanguageTerms { get; set; }
        public int DefaultMaximumCommentLength { get; set; }
        public bool DefaultEnableRateLimiting { get; set; }
        public int DefaultRateLimitSeconds { get; set; }
        public int DefaultRateLimitMaxPosts { get; set; }
        public int DefaultRateLimitWindowMinutes { get; set; }
        public bool DefaultEnableCaptcha { get; set; }
        public bool DefaultEnableNotifications { get; set; }
        public string DefaultNotificationEmailAddresses { get; set; }
        public bool DefaultIncludeCommentTextInNotifications { get; set; }
        public DateTime? ModifiedOnDate { get; set; }
        public int ModifiedByUserId { get; set; }

        public static PortalCommentSettings CreateDefaults()
        {
            return new PortalCommentSettings
            {
                PostingEnabled = true,
                GuestPostingEnabled = true,
                CentralSettingsActive = false,
                DefaultAllowGuestComments = false,
                DefaultRequireApprovalForNonEditors = true,
                DefaultEnableLanguageFilter = false,
                DefaultBlockedLanguageTerms = String.Empty,
                DefaultMaximumCommentLength = 4000,
                DefaultEnableRateLimiting = true,
                DefaultRateLimitSeconds = 60,
                DefaultRateLimitMaxPosts = 5,
                DefaultRateLimitWindowMinutes = 15,
                DefaultEnableCaptcha = false,
                DefaultEnableNotifications = false,
                DefaultNotificationEmailAddresses = String.Empty,
                DefaultIncludeCommentTextInNotifications = true,
                ModifiedOnDate = null,
                ModifiedByUserId = -1
            };
        }
    }
</script>

<div class="jacaranda-comments jc-settings jc-portal-settings">
    <asp:Panel ID="pnlAccessDenied" runat="server" Visible="false" CssClass="jc-message jc-message-error">
        Jacaranda Comments administration is restricted to DNN portal administrators and superusers.
    </asp:Panel>

    <asp:Panel ID="pnlPortalSettings" runat="server">
        <h2>Jacaranda Comments Administration</h2>
        <p class="jc-setting-help">
            Moderate pending comments from every Jacaranda Comments instance in this DNN portal and manage the commenting configuration for the whole portal in one place.
        </p>

        <asp:Panel ID="pnlMessage" runat="server" Visible="false" CssClass="jc-message">
            <asp:Literal ID="litMessage" runat="server" />
        </asp:Panel>

        <asp:HiddenField ID="hdnSecurityToken" runat="server" />

        <fieldset class="jc-settings-section jc-moderation-section">
            <legend>Pending comments</legend>
            <p class="jc-setting-help">
                This queue shows unapproved comments and replies from every Jacaranda Comments module in the current portal. Approve or reject one submission at a time.
            </p>
            <div class="jc-moderation-summary"><asp:Literal ID="litPendingSummary" runat="server" /></div>

            <asp:Panel ID="pnlNoPendingComments" runat="server" CssClass="jc-empty" Visible="false">
                No comments are currently waiting for approval on this portal.
            </asp:Panel>

            <asp:Repeater ID="rptPendingComments" runat="server" OnItemCommand="rptPendingComments_ItemCommand">
                <ItemTemplate>
                    <article class="jc-moderation-item">
                        <header class="jc-moderation-item-header">
                            <div>
                                <strong class="jc-moderation-page"><%# PendingPageTitle(Eval("PageTitle"), Eval("TabId")) %></strong>
                                <span class="jc-moderation-module"><%# PendingModuleTitle(Eval("ModuleTitle"), Eval("ModuleId")) %></span>
                            </div>
                            <div class="jc-moderation-meta">
                                <%# PendingSubmissionType(Eval("ParentCommentId")) %> #<%# Eval("CommentId") %>
                                &middot; <%# PendingCreatedDate(Eval("CreatedOnDate")) %>
                            </div>
                        </header>

                        <div class="jc-moderation-author">
                            <strong><%# Server.HtmlEncode(Convert.ToString(Eval("DisplayName"))) %></strong>
                            <span><%# PendingAuthorType(Eval("UserId")) %></span>
                            <asp:Label ID="lblPendingLanguageFlag"
                                       runat="server"
                                       CssClass="jc-language-flag"
                                       Text="Language filter"
                                       ToolTip="This submission matched the private language filter and requires moderator review."
                                       Visible='<%# PendingLanguageFlagVisible(Eval("IsLanguageFlagged")) %>' />
                        </div>

                        <div class="jc-moderation-body"><%# PendingCommentBody(Eval("CommentText")) %></div>

                        <div class="jc-moderation-actions">
                            <asp:LinkButton ID="btnApprovePending"
                                            runat="server"
                                            CommandName="ApprovePending"
                                            CommandArgument='<%# Eval("CommentId") %>'
                                            CssClass="jc-submit jc-moderation-action"
                                            CausesValidation="false">Approve</asp:LinkButton>
                            <asp:LinkButton ID="btnDeletePending"
                                            runat="server"
                                            CommandName="DeletePending"
                                            CommandArgument='<%# Eval("CommentId") %>'
                                            CssClass="jc-secondary-button jc-moderation-action jc-moderation-delete"
                                            CausesValidation="false"
                                            OnClientClick="return confirm('Reject this pending submission and hide it and any replies from view?');">Reject / Delete</asp:LinkButton>
                            <asp:HyperLink ID="lnkViewPendingPage"
                                           runat="server"
                                           CssClass="jc-admin-settings jc-moderation-action"
                                           Target="_blank"
                                           rel="noopener"
                                           NavigateUrl='<%# PendingViewUrl(Eval("TabId"), Eval("ModuleId"), Eval("CommentId")) %>'>View Page</asp:HyperLink>
                        </div>
                    </article>
                </ItemTemplate>
            </asp:Repeater>

            <asp:Panel ID="pnlPendingPager" runat="server" CssClass="jc-moderation-pager" Visible="false">
                <asp:Button ID="btnPendingPrevious" runat="server" Text="Previous" CssClass="jc-secondary-button" CausesValidation="false" OnClick="btnPendingPrevious_Click" />
                <span class="jc-moderation-page-number"><asp:Literal ID="litPendingPage" runat="server" /></span>
                <asp:Button ID="btnPendingNext" runat="server" Text="Next" CssClass="jc-secondary-button" CausesValidation="false" OnClick="btnPendingNext_Click" />
            </asp:Panel>
        </fieldset>

        <asp:Panel ID="pnlCentralMigration" runat="server" Visible="false" CssClass="jc-message jc-message-error">
            <h3>Central configuration is not yet active</h3>
            <p>
                Existing Advanced 01.02.x modules are still using their stored page-level settings. Review the portal settings below and save them for review before activating central management.
            </p>
            <p>
                The emergency posting switches below remain active immediately, as they did in 01.02.x. Activating central configuration is permanent for the Advanced branch: all Jacaranda-specific settings will then come from this Comments Administration panel.
            </p>
            <asp:Button ID="btnActivateCentral"
                        runat="server"
                        Text="Activate central settings for this portal"
                        CssClass="jc-submit"
                        ValidationGroup="PortalSettings"
                        OnClick="btnActivateCentral_Click"
                        OnClientClick="return confirm('Activate central Jacaranda Comments settings for every Advanced module in this portal? Existing local Jacaranda module settings will remain stored but will no longer control the Advanced edition. This activation cannot be undone from the module interface.');" />
        </asp:Panel>

        <asp:Panel ID="pnlCentralActive" runat="server" Visible="false" CssClass="jc-message">
            <strong>Central configuration is active.</strong>
            Every Jacaranda Comments Advanced instance in this portal uses the settings on this page. Stored page-level Jacaranda settings are retained for safety but are ignored.
        </asp:Panel>

        <fieldset class="jc-settings-section jc-emergency-settings">
            <legend>Emergency controls</legend>

            <div class="jc-setting-row">
                <asp:CheckBox ID="chkPostingEnabled" runat="server" Text="Allow new comments and replies anywhere on this portal" />
                <p class="jc-setting-warning">
                    Clearing this switch immediately disables all new comments, replies, and author correction/edit actions across the portal. Existing comments remain visible and moderators can still approve or delete them.
                </p>
            </div>

            <div class="jc-setting-row">
                <asp:CheckBox ID="chkGuestPostingEnabled" runat="server" Text="Allow guest posting anywhere on this portal" />
                <p class="jc-setting-warning">
                    Clearing this switch disables guest posting and any still-open guest correction window across every module, regardless of the normal guest setting below. Registered-user posting is unaffected.
                </p>
            </div>
        </fieldset>

        <fieldset class="jc-settings-section">
            <legend>Comment settings</legend>
            <p class="jc-setting-help">
                After central configuration is activated, these values apply to every Jacaranda Comments Advanced instance in this portal.
            </p>

            <div class="jc-setting-row">
                <asp:CheckBox ID="chkDefaultAllowGuestComments" runat="server" Text="Allow guest comments and replies" />
            </div>

            <div class="jc-setting-row">
                <asp:CheckBox ID="chkDefaultRequireApproval" runat="server" Text="Hold comments and replies from non-editors for approval" />
            </div>

            <div class="jc-setting-row">
                <asp:CheckBox ID="chkDefaultEnableLanguageFilter" runat="server" Text="Enable the private language filter" />
            </div>

            <div class="jc-field">
                <asp:Label ID="lblDefaultBlockedLanguageTerms" runat="server" AssociatedControlID="txtDefaultBlockedLanguageTerms" Text="Private language-filter terms" />
                <asp:TextBox ID="txtDefaultBlockedLanguageTerms" runat="server" TextMode="MultiLine" Rows="7" CssClass="jc-textarea jc-language-terms" />
                <p class="jc-setting-help">Enter one private term or phrase per line. Maximum 250 entries and 100 characters per entry.</p>
            </div>

            <div class="jc-field jc-setting-number">
                <asp:Label ID="lblDefaultMaximumCommentLength" runat="server" AssociatedControlID="txtDefaultMaximumCommentLength" Text="Maximum characters per comment or reply" />
                <asp:TextBox ID="txtDefaultMaximumCommentLength" runat="server" CssClass="jc-input" MaxLength="5" />
                <asp:RequiredFieldValidator ID="valDefaultMaximumCommentLengthRequired" runat="server" ValidationGroup="PortalSettings" ControlToValidate="txtDefaultMaximumCommentLength" CssClass="jc-validation" Display="Dynamic" ErrorMessage="Enter a maximum comment length." />
                <asp:RangeValidator ID="valDefaultMaximumCommentLengthRange" runat="server" ValidationGroup="PortalSettings" ControlToValidate="txtDefaultMaximumCommentLength" CssClass="jc-validation" Display="Dynamic" Type="Integer" MinimumValue="250" MaximumValue="10000" ErrorMessage="Enter a whole number from 250 to 10,000." />
            </div>
        </fieldset>

        <fieldset class="jc-settings-section">
            <legend>Rate limiting</legend>
            <div class="jc-setting-row">
                <asp:CheckBox ID="chkDefaultEnableRateLimiting" runat="server" Text="Enable rate limiting for non-editor posters" />
            </div>
            <div class="jc-setting-grid">
                <div class="jc-field">
                    <asp:Label ID="lblDefaultRateLimitSeconds" runat="server" AssociatedControlID="txtDefaultRateLimitSeconds" Text="Minimum seconds between posts" />
                    <asp:TextBox ID="txtDefaultRateLimitSeconds" runat="server" CssClass="jc-input" MaxLength="4" />
                </div>
                <div class="jc-field">
                    <asp:Label ID="lblDefaultRateLimitMaxPosts" runat="server" AssociatedControlID="txtDefaultRateLimitMaxPosts" Text="Maximum posts per window" />
                    <asp:TextBox ID="txtDefaultRateLimitMaxPosts" runat="server" CssClass="jc-input" MaxLength="3" />
                </div>
                <div class="jc-field">
                    <asp:Label ID="lblDefaultRateLimitWindowMinutes" runat="server" AssociatedControlID="txtDefaultRateLimitWindowMinutes" Text="Window length in minutes" />
                    <asp:TextBox ID="txtDefaultRateLimitWindowMinutes" runat="server" CssClass="jc-input" MaxLength="4" />
                </div>
            </div>
        </fieldset>

        <fieldset class="jc-settings-section">
            <legend>CAPTCHA</legend>
            <div class="jc-setting-row">
                <asp:CheckBox ID="chkDefaultEnableCaptcha" runat="server" Text="Enable the built-in anti-spam CAPTCHA" />
            </div>
        </fieldset>

        <fieldset class="jc-settings-section">
            <legend>Email notifications</legend>
            <div class="jc-setting-row">
                <asp:CheckBox ID="chkDefaultEnableNotifications" runat="server" Text="Email moderators when a new comment or reply is submitted" />
            </div>
            <div class="jc-field">
                <asp:Label ID="lblDefaultNotificationEmailAddresses" runat="server" AssociatedControlID="txtDefaultNotificationEmailAddresses" Text="Notification email address(es)" />
                <asp:TextBox ID="txtDefaultNotificationEmailAddresses" runat="server" TextMode="MultiLine" Rows="3" CssClass="jc-textarea" MaxLength="2000" />
                <p class="jc-setting-help">Separate multiple addresses with commas or semicolons. Leave blank to use the portal email address.</p>
            </div>
            <div class="jc-setting-row">
                <asp:CheckBox ID="chkDefaultIncludeCommentTextInNotifications" runat="server" Text="Include submitted comment text in notification emails" />
            </div>
        </fieldset>

        <div class="jc-audit-note"><asp:Literal ID="litAudit" runat="server" /></div>

        <div class="jc-settings-actions">
            <asp:Button ID="btnSave" runat="server" Text="Save comment settings" CssClass="jc-submit" ValidationGroup="PortalSettings" OnClick="btnSave_Click" OnClientClick="return confirm('Save these Jacaranda Comments settings? Emergency controls may affect every module instance on this portal.');" />
            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="jc-secondary-button" CausesValidation="false" OnClick="btnCancel_Click" />
        </div>
    </asp:Panel>
</div>
