﻿<%@ Control Language="C#" AutoEventWireup="true" Inherits="DotNetNuke.Entities.Modules.PortalModuleBase" %>
<%@ Import Namespace="System" %>
<%@ Import Namespace="System.Collections.Generic" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Import Namespace="System.Text" %>
<%@ Import Namespace="System.Security.Cryptography" %>
<%@ Import Namespace="System.Net.Mail" %>
<%@ Import Namespace="System.Web" %>
<%@ Import Namespace="System.Web.Security" %>
<%@ Import Namespace="DotNetNuke.Common" %>
<%@ Import Namespace="DotNetNuke.Common.Utilities" %>
<%@ Import Namespace="DotNetNuke.Data" %>
<%@ Import Namespace="DotNetNuke.Services.Exceptions" %>
<%@ Import Namespace="DotNetNuke.Services.Mail" %>

<script runat="server">
    private const int DefaultMaximumCommentLength = 4000;
    private const int MinimumMaximumCommentLength = 250;
    private const int MaximumMaximumCommentLength = 10000;
    private const int MinCommentLength = 3;
    private const int MinimumGuestDisplayNameLength = 2;
    private const int MaximumGuestDisplayNameLength = 100;
    private const int MaximumGuestEmailLength = 254;
    private const int RegisteredEditWindowMinutes = 15;
    private const int MaximumBlockedTermCount = 250;
    private const int MaximumBlockedTermLength = 100;
    private const string SettingPrefix = "JacarandaComments_";
    private const string CaptchaAnswerViewStateKey = "JacarandaComments_CaptchaAnswer";
    private const string SecurityTokenSessionKeyPrefix = "JacarandaComments_SecurityToken_";
    private const string PostRedirectMessageSessionKeyPrefix = "JacarandaComments_PostRedirectMessage_";
    private const string PostRedirectSuccessSessionKeyPrefix = "JacarandaComments_PostRedirectSuccess_";
    private const string PostRedirectTargetCommentSessionKeyPrefix = "JacarandaComments_PostRedirectTargetComment_";
    private const string PostRedirectMessageAnchorPrefix = "jacaranda-comments-message-";
    private const string CommentAnchorPrefix = "jacaranda-comment-";
    private const string PostRedirectStatusQueryKey = "jcposted";
    private const string PostRedirectModuleQueryKey = "jcmid";
    private const string PostRedirectCommentQueryKey = "jccid";

    private string PostRedirectMessageAnchorId
    {
        get { return PostRedirectMessageAnchorPrefix + ModuleId; }
    }

    private string CommentsTable
    {
        get
        {
            var provider = DataProvider.Instance();
            var owner = CleanSqlIdentifierPart(provider.DatabaseOwner, "dbo");
            var qualifier = CleanSqlIdentifierPart(provider.ObjectQualifier, String.Empty);

            return "[" + owner + "].[" + qualifier + "JacarandaComments]";
        }
    }

    private string SecurityTokenSessionKey
    {
        get
        {
            return SecurityTokenSessionKeyPrefix + PortalId + "_" + TabId + "_" + ModuleId + "_" + UserId;
        }
    }

    private string PostRedirectMessageSessionKey
    {
        get
        {
            return PostRedirectMessageSessionKeyPrefix + PortalId + "_" + TabId + "_" + ModuleId + "_" + UserId;
        }
    }

    private string PostRedirectSuccessSessionKey
    {
        get
        {
            return PostRedirectSuccessSessionKeyPrefix + PortalId + "_" + TabId + "_" + ModuleId + "_" + UserId;
        }
    }

    private string PostRedirectTargetCommentSessionKey
    {
        get
        {
            return PostRedirectTargetCommentSessionKeyPrefix + PortalId + "_" + TabId + "_" + ModuleId + "_" + UserId;
        }
    }

    private string ConnectionString
    {
        get { return Config.GetConnectionString(); }
    }

    protected bool IsRegisteredCommentUser
    {
        get { return UserInfo != null && UserId > -1 && !UserInfo.IsDeleted; }
    }

    private bool AllowGuestComments
    {
        get { return GetModuleSettingBool("AllowGuestComments", false); }
    }

    protected bool CanPostComments
    {
        get { return IsRegisteredCommentUser || AllowGuestComments; }
    }

    private bool IsGuestPoster
    {
        get { return CanPostComments && !IsRegisteredCommentUser; }
    }

    protected bool CanModerateComments()
    {
        return UserInfo != null && (UserInfo.IsSuperUser || IsEditable);
    }

    private bool RequireApprovalForNonEditors
    {
        get { return GetModuleSettingBool("RequireApprovalForNonEditors", true); }
    }

    private bool EnableLanguageFilter
    {
        get { return GetModuleSettingBool("EnableLanguageFilter", false); }
    }

    private string BlockedLanguageTerms
    {
        get { return GetModuleSettingString("BlockedLanguageTerms", String.Empty); }
    }

    private int MaximumCommentLength
    {
        get
        {
            return GetModuleSettingInt(
                "MaximumCommentLength",
                DefaultMaximumCommentLength,
                MinimumMaximumCommentLength,
                MaximumMaximumCommentLength);
        }
    }

    private bool EnableRateLimiting
    {
        get { return GetModuleSettingBool("EnableRateLimiting", true); }
    }

    private int RateLimitSeconds
    {
        get { return GetModuleSettingInt("RateLimitSeconds", 60, 0, 3600); }
    }

    private int RateLimitMaxPosts
    {
        get { return GetModuleSettingInt("RateLimitMaxPosts", 5, 1, 100); }
    }

    private int RateLimitWindowMinutes
    {
        get { return GetModuleSettingInt("RateLimitWindowMinutes", 15, 1, 1440); }
    }

    private bool EnableCaptcha
    {
        get { return GetModuleSettingBool("EnableCaptcha", false); }
    }

    private bool EnableNotifications
    {
        get { return GetModuleSettingBool("EnableNotifications", false); }
    }

    private string NotificationEmailAddresses
    {
        get { return GetModuleSettingString("NotificationEmailAddresses", String.Empty); }
    }

    private bool IncludeCommentTextInNotifications
    {
        get { return GetModuleSettingBool("IncludeCommentTextInNotifications", true); }
    }

    private bool CaptchaAppliesToCurrentUser
    {
        get { return EnableCaptcha && CanPostComments && !CanModerateComments(); }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            EnsureSecurityToken();
            ConfigureForm();
            ClearReplyContext();
            ClearEditContext();
            ClearCommentEntryFields();
            EnsureCaptchaChallenge();
            BindComments();
            ShowPostCompletionMessageFromRedirect();
        }
    }

    private string GetCurrentUserDisplayName()
    {
        if (UserInfo == null)
        {
            return "User";
        }

        var displayName = UserInfo.DisplayName;

        if (String.IsNullOrWhiteSpace(displayName))
        {
            displayName = UserInfo.Username;
        }

        if (String.IsNullOrWhiteSpace(displayName))
        {
            displayName = "User " + UserId;
        }

        return Truncate(displayName.Trim(), 100);
    }

    private void EnsureSecurityToken()
    {
        if (Session == null || hdnSecurityToken == null)
        {
            return;
        }

        var token = Convert.ToString(Session[SecurityTokenSessionKey]);

        if (String.IsNullOrWhiteSpace(token))
        {
            token = GenerateSecurityToken();
            Session[SecurityTokenSessionKey] = token;
        }

        hdnSecurityToken.Value = token;
    }

    private bool ValidateSecurityToken()
    {
        if (Session == null || hdnSecurityToken == null)
        {
            return false;
        }

        var expected = Convert.ToString(Session[SecurityTokenSessionKey]);
        var supplied = hdnSecurityToken.Value;

        return SecureEquals(expected, supplied);
    }

    private static string GenerateSecurityToken()
    {
        var bytes = new byte[32];

        using (var rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(bytes);
        }

        return Convert.ToBase64String(bytes);
    }

    private static bool SecureEquals(string expected, string supplied)
    {
        if (String.IsNullOrEmpty(expected) || String.IsNullOrEmpty(supplied))
        {
            return false;
        }

        var expectedBytes = Encoding.UTF8.GetBytes(expected);
        var suppliedBytes = Encoding.UTF8.GetBytes(supplied);

        var diff = expectedBytes.Length ^ suppliedBytes.Length;
        var length = Math.Min(expectedBytes.Length, suppliedBytes.Length);

        for (var i = 0; i < length; i++)
        {
            diff |= expectedBytes[i] ^ suppliedBytes[i];
        }

        return diff == 0;
    }

    private void ConfigureForm()
    {
        var isRegisteredUser = IsRegisteredCommentUser;
        var isGuest = IsGuestPoster;

        pnlCommentForm.Visible = CanPostComments;
        pnlLoginRequired.Visible = !CanPostComments;
        pnlGuestEmail.Visible = isGuest;
        pnlGuestNotice.Visible = isGuest;
        pnlCaptcha.Visible = CaptchaAppliesToCurrentUser;
        litModerationNote.Text = BuildModerationNote();

        txtDisplayName.ReadOnly = isRegisteredUser;
        txtDisplayName.Attributes["autocomplete"] = isGuest ? "name" : "off";
        txtDisplayName.Attributes["aria-required"] = isGuest ? "true" : "false";
        txtGuestEmail.Attributes["autocomplete"] = "email";
        txtGuestEmail.Attributes["aria-required"] = isGuest ? "true" : "false";

        var maximumCommentLength = MaximumCommentLength;
        // Do not apply the browser maxlength attribute. Some browsers silently
        // truncate pasted text, preventing the server from warning the user.
        txtComment.MaxLength = 0;
        txtComment.Attributes.Remove("maxlength");
        txtComment.Attributes["autocomplete"] = "off";
        txtComment.Attributes["aria-describedby"] = commentLengthHelp.ClientID;

        litCommentLimit.Text = "Maximum " + maximumCommentLength.ToString("N0") + " characters.";
        spnCommentCounter.InnerText = BuildCharacterCounterText(
            maximumCommentLength - (txtComment.Text ?? String.Empty).Length);
        txtCaptcha.Attributes["autocomplete"] = "off";
        txtWebsite.Attributes["autocomplete"] = "off";

        if (isRegisteredUser)
        {
            txtDisplayName.Text = GetCurrentUserDisplayName();
            txtGuestEmail.Text = String.Empty;
        }

        RegisterCharacterCounterScript(maximumCommentLength);
    }

    private void BindComments()
    {
        var comments = LoadVisibleComments();
        var threadedComments = BuildThreadedComments(comments);

        rptComments.DataSource = threadedComments;
        rptComments.DataBind();

        pnlNoComments.Visible = threadedComments.Rows.Count == 0;
        litCount.Text = threadedComments.Rows.Count == 1 ? "1 comment" : threadedComments.Rows.Count + " comments";
    }

    private DataTable LoadVisibleComments()
    {
        var comments = new DataTable();

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
SELECT CommentId,
       ParentCommentId,
       UserId,
       DisplayName,
       CommentText,
       IsApproved,
       IsLanguageFlagged,
       CreatedOnDate,
       EditedOnDate
FROM " + CommentsTable + @"
WHERE PortalId = @PortalId
  AND TabId = @TabId
  AND ModuleId = @ModuleId
  AND IsDeleted = 0
  AND (IsApproved = 1 OR @CanModerate = 1 OR (@CurrentUserId > -1 AND UserId = @CurrentUserId))
ORDER BY CreatedOnDate ASC;";

            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@TabId", SqlDbType.Int).Value = TabId;
            command.Parameters.Add("@ModuleId", SqlDbType.Int).Value = ModuleId;
            command.Parameters.Add("@CanModerate", SqlDbType.Bit).Value = CanModerateComments();
            command.Parameters.Add("@CurrentUserId", SqlDbType.Int).Value = UserId;

            using (var adapter = new SqlDataAdapter(command))
            {
                adapter.Fill(comments);
            }
        }

        return comments;
    }

    private DataTable BuildThreadedComments(DataTable comments)
    {
        var threadedComments = comments.Clone();

        if (!threadedComments.Columns.Contains("Depth"))
        {
            threadedComments.Columns.Add("Depth", typeof(int));
        }

        AddRowsForParent(comments, threadedComments, null, 0);

        return threadedComments;
    }

    private void AddRowsForParent(DataTable source, DataTable output, int? parentCommentId, int depth)
    {
        // Safety guard in case someone manually edits the database and creates a circular parent/reply chain.
        if (depth > 10)
        {
            return;
        }

        foreach (DataRow sourceRow in source.Rows)
        {
            var rowParentValue = sourceRow["ParentCommentId"];

            var isRootRow = rowParentValue == DBNull.Value || rowParentValue == null;
            var isMatch = parentCommentId.HasValue
                ? (!isRootRow && Convert.ToInt32(rowParentValue) == parentCommentId.Value)
                : isRootRow;

            if (!isMatch)
            {
                continue;
            }

            var outputRow = output.NewRow();

            foreach (DataColumn column in source.Columns)
            {
                outputRow[column.ColumnName] = sourceRow[column.ColumnName];
            }

            outputRow["Depth"] = depth > 3 ? 3 : depth;
            output.Rows.Add(outputRow);

            AddRowsForParent(source, output, Convert.ToInt32(sourceRow["CommentId"]), depth + 1);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        pnlMessage.Visible = false;

        if (!CanPostComments)
        {
            ShowMessage("Please sign in before posting a comment.", false);
            ConfigureForm();
            BindComments();
            return;
        }

        if (!ValidateSecurityToken())
        {
            ShowMessage("For your safety, please refresh the page and try again.", false);
            ConfigureForm();
            BindComments();
            return;
        }

        // Honeypot: real people should never fill this hidden field.
        if (!String.IsNullOrWhiteSpace(txtWebsite.Text))
        {
            ClearCommentEntryFields();
            ClearReplyContext();
            ClearEditContext();
            GenerateCaptchaChallenge();

            var honeypotMessage = "Your comment has been received. You can refresh the page safely.";
            QueuePostRedirectMessage(honeypotMessage, true);

            if (TryRedirectAfterSuccessfulPost("received"))
            {
                return;
            }

            ShowMessage(honeypotMessage, true);
            ConfigureForm();
            BindComments();
            RegisterClearCommentFormScript();
            return;
        }

        int editCommentId;
        var hasEditCommentId = TryGetSelectedEditCommentId(out editCommentId);

        if (!String.IsNullOrWhiteSpace(hdnEditCommentId.Value) && !hasEditCommentId)
        {
            ShowPostingValidationMessage("The comment selected for editing could not be found.");
            ConfigureForm();
            BindComments();
            return;
        }

        if (hasEditCommentId && !IsRegisteredCommentUser)
        {
            ClearEditContext();
            ShowPostingValidationMessage("Guest comments cannot be edited. Register or sign in before posting to receive the 15-minute edit window.");
            ConfigureForm();
            BindComments();
            return;
        }

        var isGuest = IsGuestPoster;
        var displayName = IsRegisteredCommentUser
            ? GetCurrentUserDisplayName()
            : NormalizeSingleLineText(txtDisplayName.Text);
        var guestEmail = isGuest ? (txtGuestEmail.Text ?? String.Empty).Trim() : String.Empty;
        var protectedGuestEmail = String.Empty;
        var guestRateLimitKey = String.Empty;

        if (isGuest)
        {
            if (displayName.Length < MinimumGuestDisplayNameLength)
            {
                RestoreFormContextFromHiddenFields();
                ShowPostingValidationMessage("Please enter the name you want shown with your guest comment.");
                ConfigureForm();
                BindComments();
                return;
            }

            if (displayName.Length > MaximumGuestDisplayNameLength)
            {
                RestoreFormContextFromHiddenFields();
                ShowPostingValidationMessage("Please shorten your guest name to 100 characters or fewer.");
                ConfigureForm();
                BindComments();
                return;
            }

            if (guestEmail.Length > MaximumGuestEmailLength || !IsValidEmailAddress(guestEmail))
            {
                RestoreFormContextFromHiddenFields();
                ShowPostingValidationMessage("Please enter a valid email address. It will not be displayed publicly.");
                ConfigureForm();
                BindComments();
                return;
            }

            if (!TryProtectGuestEmail(guestEmail, out protectedGuestEmail))
            {
                RestoreFormContextFromHiddenFields();
                ShowPostingValidationMessage("Your private email address could not be protected, so the guest comment was not saved. Please try again later or sign in before posting.");
                ConfigureForm();
                BindComments();
                return;
            }

            guestRateLimitKey = ComputeGuestRateLimitKey();

            if (String.IsNullOrWhiteSpace(guestRateLimitKey))
            {
                RestoreFormContextFromHiddenFields();
                ShowPostingValidationMessage("A secure guest posting session could not be confirmed. Please refresh the page and try again.");
                ConfigureForm();
                BindComments();
                return;
            }
        }

        var commentText = (txtComment.Text ?? String.Empty).Trim();

        if (commentText.Length < MinCommentLength)
        {
            RestoreFormContextFromHiddenFields();
            ShowPostingValidationMessage("Please enter a longer comment.");
            ConfigureForm();
            BindComments();
            return;
        }

        var maximumCommentLength = MaximumCommentLength;

        if (commentText.Length > maximumCommentLength)
        {
            RestoreFormContextFromHiddenFields();
            ShowPostingValidationMessage(
                "Your comment is too long. Please shorten it to "
                + maximumCommentLength.ToString("N0")
                + " characters or fewer.");
            ConfigureForm();
            BindComments();
            return;
        }

        // The configured terms are private module settings. A match never alters
        // or rejects the submitted text; it only forces the item into moderation.
        var languageFlagged = ContainsBlockedLanguage(commentText);

        string captchaError;
        if (!ValidateCaptcha(out captchaError))
        {
            RestoreFormContextFromHiddenFields();
            GenerateCaptchaChallenge();
            ShowPostingValidationMessage(captchaError);
            ConfigureForm();
            BindComments();
            return;
        }

        if (hasEditCommentId)
        {
            bool editedCommentIsReply;
            bool editedCommentIsApproved;
            string editError;

            if (!TryUpdateOwnComment(
                editCommentId,
                commentText,
                languageFlagged,
                out editedCommentIsReply,
                out editedCommentIsApproved,
                out editError))
            {
                ShowPostingValidationMessage(editError);
                ConfigureForm();
                BindComments();
                return;
            }

            SendNotificationEmail(
                editCommentId,
                editedCommentIsReply,
                editedCommentIsApproved,
                displayName,
                commentText,
                false,
                String.Empty,
                true,
                languageFlagged);

            ClearCommentEntryFields();
            ClearReplyContext();
            ClearEditContext();
            GenerateCaptchaChallenge();
            RegisterClearCommentFormScript();

            var editSuccessMessage = editedCommentIsApproved
                ? (editedCommentIsReply
                    ? "Your reply changes have been saved. You can refresh the page safely."
                    : "Your comment changes have been saved. You can refresh the page safely.")
                : (editedCommentIsReply
                    ? "Your reply changes were saved and are waiting for approval. You can refresh the page safely."
                    : "Your comment changes were saved and are waiting for approval. You can refresh the page safely.");

            var editStatusCode = editedCommentIsReply
                ? (editedCommentIsApproved ? "reply-edited" : "reply-edit-pending")
                : (editedCommentIsApproved ? "comment-edited" : "comment-edit-pending");

            QueuePostRedirectMessage(editSuccessMessage, true, editCommentId);

            if (TryRedirectAfterSuccessfulPost(editStatusCode, editCommentId))
            {
                return;
            }

            ShowMessage(editSuccessMessage, true);
            ConfigureForm();
            BindComments();
            RegisterCommentTargetFocusScript(editCommentId);
            RegisterClearCommentFormScript();
            return;
        }

        string rateLimitError;
        if (!CheckRateLimit(isGuest, guestRateLimitKey, out rateLimitError))
        {
            RestoreFormContextFromHiddenFields();
            ShowPostingValidationMessage(rateLimitError);
            ConfigureForm();
            BindComments();
            return;
        }

        int? parentCommentId = null;
        string parentDisplayName = String.Empty;

        if (!TryGetSelectedParentComment(out parentCommentId, out parentDisplayName))
        {
            ClearReplyContext();
            ShowMessage("The comment you are replying to could not be found.", false);
            ConfigureForm();
            BindComments();
            return;
        }

        // Guest submissions are always held for approval. Browser-supplied values
        // never decide approval state.
        var autoApprove = !languageFlagged
            && !isGuest
            && (CanModerateComments() || !RequireApprovalForNonEditors);
        var newCommentId = 0;

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
INSERT INTO " + CommentsTable + @" (
    PortalId,
    TabId,
    ModuleId,
    ParentCommentId,
    UserId,
    DisplayName,
    GuestEmailEncrypted,
    GuestRateLimitKey,
    CommentText,
    IsApproved,
    IsLanguageFlagged,
    IsDeleted,
    CreatedOnDate,
    CreatedByUserId
)
VALUES (
    @PortalId,
    @TabId,
    @ModuleId,
    @ParentCommentId,
    @UserId,
    @DisplayName,
    @GuestEmailEncrypted,
    @GuestRateLimitKey,
    @CommentText,
    @IsApproved,
    @IsLanguageFlagged,
    0,
    GETUTCDATE(),
    @CreatedByUserId
);

SELECT CONVERT(INT, SCOPE_IDENTITY());";

            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@TabId", SqlDbType.Int).Value = TabId;
            command.Parameters.Add("@ModuleId", SqlDbType.Int).Value = ModuleId;

            var parentParameter = command.Parameters.Add("@ParentCommentId", SqlDbType.Int);
            parentParameter.Value = parentCommentId.HasValue ? (object)parentCommentId.Value : DBNull.Value;

            var userParameter = command.Parameters.Add("@UserId", SqlDbType.Int);
            userParameter.Value = isGuest ? (object)DBNull.Value : UserId;

            command.Parameters.Add("@DisplayName", SqlDbType.NVarChar, MaximumGuestDisplayNameLength).Value = Truncate(displayName, MaximumGuestDisplayNameLength);

            var guestEmailParameter = command.Parameters.Add("@GuestEmailEncrypted", SqlDbType.NVarChar, 2048);
            guestEmailParameter.Value = isGuest ? (object)protectedGuestEmail : DBNull.Value;

            var guestRateParameter = command.Parameters.Add("@GuestRateLimitKey", SqlDbType.NVarChar, 64);
            guestRateParameter.Value = isGuest ? (object)guestRateLimitKey : DBNull.Value;

            command.Parameters.Add("@CommentText", SqlDbType.NVarChar, maximumCommentLength).Value = commentText;
            command.Parameters.Add("@IsApproved", SqlDbType.Bit).Value = autoApprove;
            command.Parameters.Add("@IsLanguageFlagged", SqlDbType.Bit).Value = languageFlagged;

            var createdByParameter = command.Parameters.Add("@CreatedByUserId", SqlDbType.Int);
            createdByParameter.Value = isGuest ? (object)DBNull.Value : UserId;

            connection.Open();
            newCommentId = Convert.ToInt32(command.ExecuteScalar());
        }

        SendNotificationEmail(
            newCommentId,
            parentCommentId.HasValue,
            autoApprove,
            displayName,
            commentText,
            isGuest,
            guestEmail,
            false,
            languageFlagged);

        ClearCommentEntryFields();
        ClearReplyContext();
        ClearEditContext();
        GenerateCaptchaChallenge();
        RegisterClearCommentFormScript();

        var successMessage = autoApprove
            ? (parentCommentId.HasValue
                ? "Your reply has been posted. You can refresh the page safely."
                : "Your comment has been posted. You can refresh the page safely.")
            : (parentCommentId.HasValue
                ? "Your reply was received and is waiting for approval. You can refresh the page safely."
                : "Your comment was received and is waiting for approval. You can refresh the page safely.");

        var statusCode = GetPostRedirectStatusCode(parentCommentId.HasValue, autoApprove);

        // Registered authors can see their own pending submissions. Guest pending
        // submissions remain at the confirmation message because no public identity
        // is available after redirect.
        var redirectTargetCommentId = !isGuest ? (int?)newCommentId : null;

        QueuePostRedirectMessage(successMessage, true, redirectTargetCommentId);

        if (TryRedirectAfterSuccessfulPost(statusCode, redirectTargetCommentId))
        {
            return;
        }

        ShowMessage(successMessage, true);
        ConfigureForm();
        BindComments();

        if (redirectTargetCommentId.HasValue)
        {
            RegisterCommentTargetFocusScript(redirectTargetCommentId.Value);
        }

        RegisterClearCommentFormScript();
        return;
    }

    protected void btnCancelReply_Click(object sender, EventArgs e)
    {
        pnlMessage.Visible = false;
        ClearReplyContext();
        ConfigureForm();
        EnsureCaptchaChallenge();
        BindComments();
        RegisterCommentFormFocusScript();
    }

    protected void btnCancelEdit_Click(object sender, EventArgs e)
    {
        pnlMessage.Visible = false;
        ClearEditContext();
        ConfigureForm();
        EnsureCaptchaChallenge();
        BindComments();
        RegisterCommentFormFocusScript();
    }

    protected void rptComments_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
    {
        pnlMessage.Visible = false;

        int commentId;
        if (!Int32.TryParse(Convert.ToString(e.CommandArgument), out commentId))
        {
            ShowMessage("That comment could not be found.", false);
            return;
        }

        if (!ValidateSecurityToken())
        {
            ShowMessage("For your safety, please refresh the page and try again.", false);
            ConfigureForm();
            BindComments();
            return;
        }

        if (String.Equals(e.CommandName, "EditComment", StringComparison.OrdinalIgnoreCase))
        {
            if (!IsRegisteredCommentUser)
            {
                ShowMessage("Guest comments cannot be edited. Register or sign in before posting to receive the 15-minute edit window.", false);
                ConfigureForm();
                BindComments();
                return;
            }

            string editableCommentText;
            bool editableCommentIsReply;
            string editError;

            if (!TryLoadEditableComment(
                commentId,
                out editableCommentText,
                out editableCommentIsReply,
                out editError))
            {
                ShowMessage(editError, false);
                ConfigureForm();
                BindComments();
                return;
            }

            SetEditContext(commentId, editableCommentIsReply, editableCommentText, true);
            ConfigureForm();
            EnsureCaptchaChallenge();
            BindComments();
            RegisterCommentFormFocusScript();
            return;
        }

        if (String.Equals(e.CommandName, "ReplyTo", StringComparison.OrdinalIgnoreCase))
        {
            if (!CanPostComments)
            {
                ShowMessage("Please sign in before replying, or enable guest commenting in this module's settings.", false);
                ConfigureForm();
                BindComments();
                return;
            }

            string replyToDisplayName;
            if (!TryGetCommentDisplayName(commentId, out replyToDisplayName))
            {
                ShowMessage("The comment you are replying to could not be found.", false);
                ConfigureForm();
                BindComments();
                return;
            }

            SetReplyContext(commentId, replyToDisplayName);
            ConfigureForm();
            EnsureCaptchaChallenge();
            BindComments();
            RegisterCommentFormFocusScript();
            return;
        }

        if (!CanModerateComments())
        {
            ShowMessage("You do not have permission to moderate comments.", false);
            return;
        }

        string moderationMessage = String.Empty;
        string moderationStatusCode = String.Empty;

        if (String.Equals(e.CommandName, "Approve", StringComparison.OrdinalIgnoreCase))
        {
            UpdateCommentApproval(commentId, true);
            moderationMessage = "Comment approved.";
            moderationStatusCode = "comment-approved";
        }
        else if (String.Equals(e.CommandName, "Delete", StringComparison.OrdinalIgnoreCase))
        {
            SoftDeleteComment(commentId);
            moderationMessage = "Comment deleted.";
            moderationStatusCode = "comment-deleted";
        }

        if (!String.IsNullOrWhiteSpace(moderationMessage))
        {
            QueuePostRedirectMessage(moderationMessage, true);

            if (TryRedirectAfterSuccessfulPost(moderationStatusCode))
            {
                return;
            }

            ShowMessage(moderationMessage, true);
        }

        ConfigureForm();
        BindComments();
    }

    private bool TryGetSelectedEditCommentId(out int commentId)
    {
        commentId = 0;
        var rawCommentId = (hdnEditCommentId.Value ?? String.Empty).Trim();

        return !String.IsNullOrWhiteSpace(rawCommentId)
            && Int32.TryParse(rawCommentId, out commentId)
            && commentId > 0;
    }

    private bool TryLoadEditableComment(
        int commentId,
        out string commentText,
        out bool isReply,
        out string errorMessage)
    {
        commentText = String.Empty;
        isReply = false;
        errorMessage = "That comment cannot be edited.";

        if (!IsRegisteredCommentUser || commentId <= 0)
        {
            return false;
        }

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
SELECT TOP 1 CommentText,
       ParentCommentId,
       CreatedOnDate
FROM " + CommentsTable + @"
WHERE CommentId = @CommentId
  AND PortalId = @PortalId
  AND TabId = @TabId
  AND ModuleId = @ModuleId
  AND UserId = @UserId
  AND IsDeleted = 0;";

            command.Parameters.Add("@CommentId", SqlDbType.Int).Value = commentId;
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@TabId", SqlDbType.Int).Value = TabId;
            command.Parameters.Add("@ModuleId", SqlDbType.Int).Value = ModuleId;
            command.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;

            connection.Open();

            using (var reader = command.ExecuteReader())
            {
                if (!reader.Read())
                {
                    return false;
                }

                var createdOnUtc = DateTime.SpecifyKind(
                    Convert.ToDateTime(reader["CreatedOnDate"]),
                    DateTimeKind.Utc);

                if (DateTime.UtcNow > createdOnUtc.AddMinutes(RegisteredEditWindowMinutes))
                {
                    errorMessage = "The 15-minute editing window for this comment has expired.";
                    return false;
                }

                commentText = Convert.ToString(reader["CommentText"]);
                isReply = reader["ParentCommentId"] != DBNull.Value;
                return true;
            }
        }
    }

    private bool TryUpdateOwnComment(
        int commentId,
        string commentText,
        bool languageFlagged,
        out bool isReply,
        out bool isApproved,
        out string errorMessage)
    {
        isReply = false;
        isApproved = false;
        errorMessage = "The comment could not be updated. The 15-minute editing window may have expired.";

        if (!IsRegisteredCommentUser || commentId <= 0)
        {
            return false;
        }

        var approvalAfterEdit = !languageFlagged
            && (CanModerateComments() || !RequireApprovalForNonEditors);

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
UPDATE " + CommentsTable + @"
SET CommentText = @CommentText,
    IsApproved = @IsApproved,
    IsLanguageFlagged = @IsLanguageFlagged,
    EditedOnDate = GETUTCDATE(),
    EditedByUserId = @UserId,
    LastModifiedOnDate = GETUTCDATE(),
    LastModifiedByUserId = @UserId
OUTPUT inserted.ParentCommentId,
       inserted.IsApproved
WHERE CommentId = @CommentId
  AND PortalId = @PortalId
  AND TabId = @TabId
  AND ModuleId = @ModuleId
  AND UserId = @UserId
  AND IsDeleted = 0
  AND CreatedOnDate >= DATEADD(MINUTE, -@EditWindowMinutes, GETUTCDATE());";

            command.Parameters.Add("@CommentText", SqlDbType.NVarChar, MaximumCommentLength).Value = commentText;
            command.Parameters.Add("@IsApproved", SqlDbType.Bit).Value = approvalAfterEdit;
            command.Parameters.Add("@IsLanguageFlagged", SqlDbType.Bit).Value = languageFlagged;
            command.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
            command.Parameters.Add("@CommentId", SqlDbType.Int).Value = commentId;
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@TabId", SqlDbType.Int).Value = TabId;
            command.Parameters.Add("@ModuleId", SqlDbType.Int).Value = ModuleId;
            command.Parameters.Add("@EditWindowMinutes", SqlDbType.Int).Value = RegisteredEditWindowMinutes;

            connection.Open();

            using (var reader = command.ExecuteReader())
            {
                if (!reader.Read())
                {
                    return false;
                }

                isReply = reader["ParentCommentId"] != DBNull.Value;
                isApproved = Convert.ToBoolean(reader["IsApproved"]);
                return true;
            }
        }
    }

    private bool TryGetSelectedParentComment(out int? parentCommentId, out string displayName)
    {
        parentCommentId = null;
        displayName = String.Empty;

        var rawParentCommentId = (hdnParentCommentId.Value ?? String.Empty).Trim();

        if (String.IsNullOrWhiteSpace(rawParentCommentId))
        {
            return true;
        }

        int parsedParentCommentId;
        if (!Int32.TryParse(rawParentCommentId, out parsedParentCommentId))
        {
            return false;
        }

        if (!TryGetCommentDisplayName(parsedParentCommentId, out displayName))
        {
            return false;
        }

        parentCommentId = parsedParentCommentId;
        return true;
    }

    private void RestoreReplyContextFromHiddenField()
    {
        int? parentCommentId;
        string displayName;

        if (TryGetSelectedParentComment(out parentCommentId, out displayName) && parentCommentId.HasValue)
        {
            SetReplyContext(parentCommentId.Value, displayName);
        }
    }

    private bool TryGetCommentDisplayName(int commentId, out string displayName)
    {
        displayName = String.Empty;

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
SELECT TOP 1 DisplayName
FROM " + CommentsTable + @"
WHERE CommentId = @CommentId
  AND PortalId = @PortalId
  AND TabId = @TabId
  AND ModuleId = @ModuleId
  AND IsDeleted = 0
  AND (IsApproved = 1 OR @CanModerate = 1);";

            command.Parameters.Add("@CommentId", SqlDbType.Int).Value = commentId;
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@TabId", SqlDbType.Int).Value = TabId;
            command.Parameters.Add("@ModuleId", SqlDbType.Int).Value = ModuleId;
            command.Parameters.Add("@CanModerate", SqlDbType.Bit).Value = CanModerateComments();

            connection.Open();
            var result = command.ExecuteScalar();

            if (result == null || result == DBNull.Value)
            {
                return false;
            }

            displayName = Convert.ToString(result);
            return true;
        }
    }

    private void SetReplyContext(int parentCommentId, string displayName)
    {
        ClearEditContext();
        hdnParentCommentId.Value = parentCommentId.ToString();
        pnlReplyContext.Visible = true;
        litReplyContext.Text = "Replying to " + Server.HtmlEncode(displayName);
        litFormTitle.Text = "Leave a reply";
        btnSubmit.Text = "Post reply";
    }

    private void ClearReplyContext()
    {
        hdnParentCommentId.Value = String.Empty;
        pnlReplyContext.Visible = false;
        litReplyContext.Text = String.Empty;

        if (hdnEditCommentId == null || String.IsNullOrWhiteSpace(hdnEditCommentId.Value))
        {
            litFormTitle.Text = "Leave a comment";
            btnSubmit.Text = "Post comment";
        }
    }

    private void SetEditContext(int commentId, bool isReply, string commentText, bool replaceCommentText)
    {
        ClearReplyContext();
        hdnEditCommentId.Value = commentId.ToString();
        pnlEditContext.Visible = true;
        litEditContext.Text = isReply
            ? "Editing your reply. Changes must be saved within 15 minutes of the original post."
            : "Editing your comment. Changes must be saved within 15 minutes of the original post.";
        litFormTitle.Text = isReply ? "Edit your reply" : "Edit your comment";
        btnSubmit.Text = "Save changes";

        if (replaceCommentText)
        {
            txtComment.Text = commentText ?? String.Empty;
        }
    }

    private void ClearEditContext()
    {
        hdnEditCommentId.Value = String.Empty;
        pnlEditContext.Visible = false;
        litEditContext.Text = String.Empty;

        if (hdnParentCommentId == null || String.IsNullOrWhiteSpace(hdnParentCommentId.Value))
        {
            litFormTitle.Text = "Leave a comment";
            btnSubmit.Text = "Post comment";
        }
    }

    private void RestoreFormContextFromHiddenFields()
    {
        int editCommentId;

        if (TryGetSelectedEditCommentId(out editCommentId) && IsRegisteredCommentUser)
        {
            string existingText;
            bool isReply;
            string errorMessage;

            if (TryLoadEditableComment(editCommentId, out existingText, out isReply, out errorMessage))
            {
                SetEditContext(editCommentId, isReply, existingText, false);
                return;
            }
        }

        RestoreReplyContextFromHiddenField();
    }

    private void ClearCommentEntryFields()
    {
        txtComment.Text = String.Empty;
        txtCaptcha.Text = String.Empty;
        txtWebsite.Text = String.Empty;

        if (!IsRegisteredCommentUser)
        {
            txtDisplayName.Text = String.Empty;
            txtGuestEmail.Text = String.Empty;
        }
    }


    private string BuildCharacterCounterText(int remainingCharacters)
    {
        if (remainingCharacters < 0)
        {
            return Math.Abs(remainingCharacters).ToString("N0") + " characters over the limit.";
        }

        return remainingCharacters.ToString("N0") + " characters remaining.";
    }

    private void RegisterCharacterCounterScript(int maximumCommentLength)
    {
        if (Page == null || txtComment == null || spnCommentCounter == null)
        {
            return;
        }

        var textBoxId = HttpUtility.JavaScriptStringEncode(txtComment.ClientID);
        var counterId = HttpUtility.JavaScriptStringEncode(spnCommentCounter.ClientID);

        var script = @"
(function () {
    var field = document.getElementById('" + textBoxId + @"');
    var counter = document.getElementById('" + counterId + @"');
    var maximumLength = " + maximumCommentLength + @";

    if (!field || !counter) { return; }

    // Keep the full text available so the server can reject an over-limit
    // submission without silently discarding pasted content.
    field.removeAttribute('maxlength');

    function formatNumber(value) {
        try {
            return value.toLocaleString();
        } catch (e) {
            return value.toString();
        }
    }

    function updateCounter() {
        var remaining = maximumLength - field.value.length;

        if (remaining < 0) {
            counter.textContent = formatNumber(Math.abs(remaining)) + ' characters over the limit.';
            counter.classList.add('jc-over-limit');
            field.setAttribute('aria-invalid', 'true');
        } else {
            counter.textContent = formatNumber(remaining) + ' characters remaining.';
            counter.classList.remove('jc-over-limit');
            field.removeAttribute('aria-invalid');
        }
    }

    field.addEventListener('input', updateCounter);
    updateCounter();
})();";

        RegisterStartupScript("JacarandaCommentsCharacterCounter_" + ModuleId, script);
    }


    private void RegisterStartupScript(string key, string script)
    {
        if (Page == null || String.IsNullOrWhiteSpace(script))
        {
            return;
        }

        try
        {
            var scriptManager = System.Web.UI.ScriptManager.GetCurrent(Page);

            if (scriptManager != null)
            {
                System.Web.UI.ScriptManager.RegisterStartupScript(this, GetType(), key, script, true);
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), key, script, true);
            }
        }
        catch
        {
            try
            {
                Page.ClientScript.RegisterStartupScript(GetType(), key, script, true);
            }
            catch
            {
                // Do not break comment posting because a cleanup script could not be registered.
            }
        }
    }

    private void RegisterClearCommentFormScript()
    {
        if (Page == null)
        {
            return;
        }

        var guestFieldCleanup = IsRegisteredCommentUser
            ? String.Empty
            : "clearField('" + HttpUtility.JavaScriptStringEncode(txtDisplayName.ClientID) + "');\n"
                + "clearField('" + HttpUtility.JavaScriptStringEncode(txtGuestEmail.ClientID) + "');\n";

        var script = @"
(function () {
    function clearField(id) {
        var field = document.getElementById(id);
        if (!field) {
            return;
        }

        field.value = '';
        field.defaultValue = '';
    }

    clearField('" + HttpUtility.JavaScriptStringEncode(txtComment.ClientID) + @"');
    clearField('" + HttpUtility.JavaScriptStringEncode(txtCaptcha.ClientID) + @"');
    clearField('" + HttpUtility.JavaScriptStringEncode(txtWebsite.ClientID) + @"');
    " + guestFieldCleanup + @"
})();";

        RegisterStartupScript("JacarandaCommentsClearForm_" + ModuleId, script);
    }

    private bool ContainsBlockedLanguage(string commentText)
    {
        if (!EnableLanguageFilter || String.IsNullOrWhiteSpace(commentText))
        {
            return false;
        }

        var normalizedComment = NormalizeLanguageFilterText(commentText);

        if (normalizedComment.Length == 0)
        {
            return false;
        }

        var searchableComment = " " + normalizedComment + " ";
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var rawTerms = BlockedLanguageTerms.Replace("\r\n", "\n").Replace('\r', '\n')
            .Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
        var acceptedTermCount = 0;

        foreach (var rawTerm in rawTerms)
        {
            var term = (rawTerm ?? String.Empty).Trim();

            if (term.Length > MaximumBlockedTermLength)
            {
                term = term.Substring(0, MaximumBlockedTermLength);
            }

            var normalizedTerm = NormalizeLanguageFilterText(term);

            if (normalizedTerm.Length == 0 || !seen.Add(normalizedTerm))
            {
                continue;
            }

            acceptedTermCount++;

            if (searchableComment.IndexOf(" " + normalizedTerm + " ", StringComparison.Ordinal) >= 0)
            {
                return true;
            }

            if (acceptedTermCount >= MaximumBlockedTermCount)
            {
                break;
            }
        }

        return false;
    }

    private static string NormalizeLanguageFilterText(string value)
    {
        if (String.IsNullOrWhiteSpace(value))
        {
            return String.Empty;
        }

        string normalized;

        try
        {
            normalized = value.Normalize(NormalizationForm.FormKC).ToLowerInvariant();
        }
        catch (ArgumentException)
        {
            normalized = value.ToLowerInvariant();
        }

        var output = new StringBuilder(normalized.Length);
        var previousWasSeparator = true;

        foreach (var character in normalized)
        {
            if (Char.IsLetterOrDigit(character))
            {
                output.Append(character);
                previousWasSeparator = false;
            }
            else if (!previousWasSeparator)
            {
                output.Append(' ');
                previousWasSeparator = true;
            }
        }

        return output.ToString().Trim();
    }

    private bool CheckRateLimit(bool isGuest, string guestRateLimitKey, out string errorMessage)
    {
        errorMessage = String.Empty;

        if (!EnableRateLimiting || CanModerateComments())
        {
            return true;
        }

        var windowMinutes = RateLimitWindowMinutes;
        var maxPosts = RateLimitMaxPosts;
        var minimumSeconds = RateLimitSeconds;

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
SELECT COUNT(1) AS RecentPostCount,
       ISNULL(DATEDIFF(SECOND, MAX(CreatedOnDate), GETUTCDATE()), 999999) AS SecondsSinceLastPost
FROM " + CommentsTable + @"
WHERE PortalId = @PortalId
  AND IsDeleted = 0
  AND ((@IsGuest = 0 AND CreatedByUserId = @UserId)
       OR (@IsGuest = 1 AND GuestRateLimitKey = @GuestRateLimitKey))
  AND CreatedOnDate >= DATEADD(MINUTE, -@WindowMinutes, GETUTCDATE());";

            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
            command.Parameters.Add("@IsGuest", SqlDbType.Bit).Value = isGuest;
            command.Parameters.Add("@GuestRateLimitKey", SqlDbType.NVarChar, 64).Value = isGuest
                ? (object)(guestRateLimitKey ?? String.Empty)
                : DBNull.Value;
            command.Parameters.Add("@WindowMinutes", SqlDbType.Int).Value = windowMinutes;

            connection.Open();

            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    var recentPostCount = Convert.ToInt32(reader["RecentPostCount"]);
                    var secondsSinceLastPost = Convert.ToInt32(reader["SecondsSinceLastPost"]);

                    if (minimumSeconds > 0 && secondsSinceLastPost < minimumSeconds)
                    {
                        var secondsToWait = minimumSeconds - secondsSinceLastPost;
                        errorMessage = "Please wait " + secondsToWait + " more second" + (secondsToWait == 1 ? "" : "s") + " before posting again.";
                        return false;
                    }

                    if (recentPostCount >= maxPosts)
                    {
                        errorMessage = "You have reached the comment limit for this time window. Please try again later.";
                        return false;
                    }
                }
            }
        }

        return true;
    }

    private string NormalizeSingleLineText(string value)
    {
        value = (value ?? String.Empty).Trim();

        if (String.IsNullOrWhiteSpace(value))
        {
            return String.Empty;
        }

        var output = new StringBuilder(value.Length);
        var previousWasWhitespace = false;

        foreach (var character in value)
        {
            if (Char.IsControl(character) || Char.IsWhiteSpace(character))
            {
                if (!previousWasWhitespace)
                {
                    output.Append(' ');
                    previousWasWhitespace = true;
                }
            }
            else
            {
                output.Append(character);
                previousWasWhitespace = false;
            }
        }

        return output.ToString().Trim();
    }

    private bool TryProtectGuestEmail(string email, out string protectedEmail)
    {
        protectedEmail = String.Empty;

        if (String.IsNullOrWhiteSpace(email))
        {
            return false;
        }

        try
        {
            var emailBytes = Encoding.UTF8.GetBytes(email.Trim());
            var protectedBytes = MachineKey.Protect(
                emailBytes,
                "JacarandaComments",
                "GuestEmail",
                PortalId.ToString(),
                ModuleId.ToString());

            if (protectedBytes == null || protectedBytes.Length == 0)
            {
                return false;
            }

            protectedEmail = Convert.ToBase64String(protectedBytes);
            return protectedEmail.Length <= 2048;
        }
        catch (Exception ex)
        {
            Exceptions.LogException(ex);
            return false;
        }
    }

    private string ComputeGuestRateLimitKey()
    {
        if (Request == null)
        {
            return String.Empty;
        }

        var remoteAddress = (Request.UserHostAddress ?? String.Empty).Trim();
        var userAgent = (Request.UserAgent ?? String.Empty).Trim();

        if (userAgent.Length > 256)
        {
            userAgent = userAgent.Substring(0, 256);
        }

        if (String.IsNullOrWhiteSpace(remoteAddress) && String.IsNullOrWhiteSpace(userAgent))
        {
            return String.Empty;
        }

        // Store only a one-way pseudonymous value. The raw network address and
        // browser signature are never written to the comments table.
        var source = "JacarandaCommentsGuestRate|" + PortalId + "|" + ModuleId
            + "|" + remoteAddress + "|" + userAgent;

        try
        {
            using (var sha256 = SHA256.Create())
            {
                var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(source));
                var output = new StringBuilder(hash.Length * 2);

                foreach (var value in hash)
                {
                    output.Append(value.ToString("x2"));
                }

                return output.ToString();
            }
        }
        catch (Exception ex)
        {
            Exceptions.LogException(ex);
            return String.Empty;
        }
    }

    private void EnsureCaptchaChallenge()
    {
        if (CaptchaAppliesToCurrentUser && ViewState[CaptchaAnswerViewStateKey] == null)
        {
            GenerateCaptchaChallenge();
        }
    }

    private void GenerateCaptchaChallenge()
    {
        if (!CaptchaAppliesToCurrentUser)
        {
            litCaptchaQuestion.Text = String.Empty;
            ViewState[CaptchaAnswerViewStateKey] = null;
            return;
        }

        var seed = unchecked(Environment.TickCount + (ModuleId * 31) + (UserId * 17));
        var random = new Random(seed);
        var left = random.Next(2, 10);
        var right = random.Next(1, 9);

        ViewState[CaptchaAnswerViewStateKey] = left + right;
        litCaptchaQuestion.Text = left + " + " + right + " =";
        txtCaptcha.Text = String.Empty;
    }

    private bool ValidateCaptcha(out string errorMessage)
    {
        errorMessage = String.Empty;

        if (!CaptchaAppliesToCurrentUser)
        {
            return true;
        }

        var expectedValue = ViewState[CaptchaAnswerViewStateKey];

        if (expectedValue == null)
        {
            errorMessage = "Please answer the anti-spam question.";
            return false;
        }

        int expectedAnswer;
        if (!Int32.TryParse(Convert.ToString(expectedValue), out expectedAnswer))
        {
            errorMessage = "Please answer the anti-spam question again.";
            return false;
        }

        int suppliedAnswer;
        if (!Int32.TryParse((txtCaptcha.Text ?? String.Empty).Trim(), out suppliedAnswer) || suppliedAnswer != expectedAnswer)
        {
            errorMessage = "The anti-spam answer was not correct. Please try again.";
            return false;
        }

        return true;
    }

    private void SendNotificationEmail(
        int commentId,
        bool isReply,
        bool isApproved,
        string displayName,
        string commentText,
        bool isGuest,
        string guestEmail,
        bool isEdit,
        bool languageFlagged)
    {
        if (!EnableNotifications)
        {
            return;
        }

        var recipients = GetNotificationRecipients();

        if (recipients.Count == 0)
        {
            return;
        }

        var fromAddress = PortalSettings != null ? PortalSettings.Email : String.Empty;

        if (String.IsNullOrWhiteSpace(fromAddress) || !IsValidEmailAddress(fromAddress))
        {
            fromAddress = recipients[0];
        }

        if (String.IsNullOrWhiteSpace(fromAddress) || !IsValidEmailAddress(fromAddress))
        {
            return;
        }

        var pageTitle = GetPageTitle();
        var subjectAction = !isApproved
            ? "Comment awaiting approval"
            : (isEdit ? "Comment edited" : "New comment");
        var subject = CleanEmailHeader(subjectAction + " — " + pageTitle);
        var body = BuildNotificationBody(
            commentId,
            isReply,
            isApproved,
            displayName,
            commentText,
            isGuest,
            guestEmail,
            isEdit,
            languageFlagged);

        foreach (var recipient in recipients)
        {
            try
            {
                Mail.SendEmail(fromAddress, recipient, subject, body);
            }
            catch (Exception ex)
            {
                // Do not block comment posting if SMTP is not available.
                Exceptions.LogException(ex);
            }
        }
    }

    private List<string> GetNotificationRecipients()
    {
        var recipients = new List<string>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var raw = NotificationEmailAddresses;

        if (String.IsNullOrWhiteSpace(raw) && PortalSettings != null)
        {
            raw = PortalSettings.Email;
        }

        if (String.IsNullOrWhiteSpace(raw))
        {
            return recipients;
        }

        var parts = raw.Split(new[] { ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

        foreach (var part in parts)
        {
            var email = (part ?? String.Empty).Trim();

            if (String.IsNullOrWhiteSpace(email))
            {
                continue;
            }

            if (!IsValidEmailAddress(email))
            {
                continue;
            }

            if (seen.Add(email))
            {
                recipients.Add(email);
            }
        }

        return recipients;
    }

    private bool IsValidEmailAddress(string email)
    {
        if (String.IsNullOrWhiteSpace(email))
        {
            return false;
        }

        email = email.Trim();

        if (email.IndexOfAny(new[] { '\r', '\n' }) >= 0)
        {
            return false;
        }

        try
        {
            var address = new MailAddress(email);

            if (!String.Equals(address.Address, email, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            try
            {
                return Mail.IsValidEmailAddress(email, PortalId);
            }
            catch
            {
                return true;
            }
        }
        catch
        {
            return false;
        }
    }

    private string CleanEmailHeader(string value)
    {
        value = (value ?? String.Empty).Replace("\r", " ").Replace("\n", " ").Trim();

        if (value.Length > 150)
        {
            value = value.Substring(0, 150);
        }

        return value;
    }

    private static string CleanSqlIdentifierPart(string value, string defaultValue)
    {
        value = (value ?? String.Empty).Trim();

        if (value.EndsWith(".", StringComparison.Ordinal))
        {
            value = value.Substring(0, value.Length - 1);
        }

        value = value.Replace("[", String.Empty).Replace("]", String.Empty).Trim();

        if (String.IsNullOrEmpty(value))
        {
            return defaultValue ?? String.Empty;
        }

        for (var i = 0; i < value.Length; i++)
        {
            var c = value[i];

            if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_'))
            {
                return defaultValue ?? String.Empty;
            }
        }

        return value;
    }

    private string BuildNotificationBody(
        int commentId,
        bool isReply,
        bool isApproved,
        string displayName,
        string commentText,
        bool isGuest,
        string guestEmail,
        bool isEdit,
        bool languageFlagged)
    {
        var body = new StringBuilder();

        body.AppendLine((isEdit ? "A " : "A new ")
            + (isGuest ? "guest " : String.Empty)
            + (isReply ? "reply" : "comment")
            + (isEdit ? " has been edited." : " has been submitted."));
        body.AppendLine();
        body.AppendLine("Portal: " + EncodeForNotification(GetPortalName()));
        body.AppendLine("Page title: " + EncodeForNotification(GetPageTitle()));
        body.AppendLine("Page link: " + EncodeForNotification(GetPageUrl()));
        body.AppendLine("Module: " + EncodeForNotification(ModuleConfiguration != null ? ModuleConfiguration.ModuleTitle : "Jacaranda Comments"));
        body.AppendLine("Comment ID: " + commentId);
        body.AppendLine("Author: " + EncodeForNotification(displayName));
        body.AppendLine("Author type: " + (isGuest ? "Guest" : "Registered DNN user"));

        if (isGuest && !String.IsNullOrWhiteSpace(guestEmail))
        {
            body.AppendLine("Private guest email: " + EncodeForNotification(guestEmail));
        }

        body.AppendLine("Status: " + (isApproved ? "Approved" : "Waiting for approval"));

        if (languageFlagged)
        {
            body.AppendLine("Private language filter: Triggered — review the submission before approval.");
        }

        body.AppendLine((isEdit ? "Edited UTC: " : "Submitted UTC: ") + DateTime.UtcNow.ToString("dd MMM yyyy, h:mm tt") + " UTC");

        if (IncludeCommentTextInNotifications)
        {
            body.AppendLine();
            body.AppendLine("Comment:");
            body.AppendLine(EncodeForNotification(commentText));
        }

        body.AppendLine();
        body.AppendLine("Sign in to DNN and open the page/module settings to moderate comments.");

        return body.ToString();
    }

    private string EncodeForNotification(string value)
    {
        return HttpUtility.HtmlEncode(value ?? String.Empty);
    }

    private string GetPortalName()
    {
        if (PortalSettings != null && !String.IsNullOrWhiteSpace(PortalSettings.PortalName))
        {
            return PortalSettings.PortalName;
        }

        return "DNN site";
    }

    private string GetPageTitle()
    {
        try
        {
            if (PortalSettings != null && PortalSettings.ActiveTab != null)
            {
                var tabName = (PortalSettings.ActiveTab.TabName ?? String.Empty).Trim();

                if (!String.IsNullOrWhiteSpace(tabName))
                {
                    return tabName;
                }
            }
        }
        catch
        {
            // Fall through to a safe, non-empty subject value.
        }

        return "DNN page";
    }

    private string GetPageUrl()
    {
        try
        {
            var pageUrl = DotNetNuke.Common.Globals.NavigateURL(TabId);

            if (Request != null && !String.IsNullOrWhiteSpace(pageUrl) && !pageUrl.StartsWith("http", StringComparison.OrdinalIgnoreCase))
            {
                if (pageUrl.StartsWith("/", StringComparison.Ordinal))
                {
                    pageUrl = Request.Url.GetLeftPart(UriPartial.Authority) + pageUrl;
                }
                else
                {
                    pageUrl = Request.Url.GetLeftPart(UriPartial.Authority) + ResolveUrl(pageUrl);
                }
            }

            return pageUrl;
        }
        catch
        {
            return String.Empty;
        }
    }

    private string BuildModerationNote()
    {
        string moderationText;

        if (IsGuestPoster)
        {
            moderationText = "Guest comments and replies are always held for approval. Your email address is private and is not displayed publicly. Guest submissions cannot be edited after posting; register or sign in first to receive a 15-minute edit window.";
        }
        else
        {
            moderationText = RequireApprovalForNonEditors
                ? "Comments and replies from non-editors are held for approval. Registered authors can edit their own submissions for 15 minutes after posting."
                : "Comments and replies from signed-in users are posted immediately. Registered authors can edit their own submissions for 15 minutes after posting.";
        }

        if (EnableRateLimiting && !CanModerateComments())
        {
            moderationText += " Posting is rate-limited to help reduce spam.";
        }

        if (CaptchaAppliesToCurrentUser)
        {
            moderationText += " Please answer the anti-spam question before posting.";
        }

        return moderationText;
    }

    private void UpdateCommentApproval(int commentId, bool isApproved)
    {
        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
UPDATE " + CommentsTable + @"
SET IsApproved = @IsApproved,
    LastModifiedOnDate = GETUTCDATE(),
    LastModifiedByUserId = @UserId
WHERE CommentId = @CommentId
  AND PortalId = @PortalId
  AND TabId = @TabId
  AND ModuleId = @ModuleId;";

            command.Parameters.Add("@IsApproved", SqlDbType.Bit).Value = isApproved;
            command.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
            command.Parameters.Add("@CommentId", SqlDbType.Int).Value = commentId;
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@TabId", SqlDbType.Int).Value = TabId;
            command.Parameters.Add("@ModuleId", SqlDbType.Int).Value = ModuleId;

            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    private void SoftDeleteComment(int commentId)
    {
        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
UPDATE " + CommentsTable + @"
SET IsDeleted = 1,
    LastModifiedOnDate = GETUTCDATE(),
    LastModifiedByUserId = @UserId
WHERE CommentId = @CommentId
  AND PortalId = @PortalId
  AND TabId = @TabId
  AND ModuleId = @ModuleId;";

            command.Parameters.Add("@UserId", SqlDbType.Int).Value = UserId;
            command.Parameters.Add("@CommentId", SqlDbType.Int).Value = commentId;
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@TabId", SqlDbType.Int).Value = TabId;
            command.Parameters.Add("@ModuleId", SqlDbType.Int).Value = ModuleId;

            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    private string GetModuleSettingString(string name, string defaultValue)
    {
        var key = SettingPrefix + name;
        var rawValue = Settings[key];

        if (rawValue == null)
        {
            return defaultValue;
        }

        var value = Convert.ToString(rawValue);

        return String.IsNullOrWhiteSpace(value) ? defaultValue : value;
    }

    private bool GetModuleSettingBool(string name, bool defaultValue)
    {
        var raw = GetModuleSettingString(name, defaultValue.ToString());

        bool boolValue;
        if (Boolean.TryParse(raw, out boolValue))
        {
            return boolValue;
        }

        return String.Equals(raw, "1", StringComparison.OrdinalIgnoreCase)
            || String.Equals(raw, "yes", StringComparison.OrdinalIgnoreCase)
            || String.Equals(raw, "on", StringComparison.OrdinalIgnoreCase);
    }

    private int GetModuleSettingInt(string name, int defaultValue, int minValue, int maxValue)
    {
        var raw = GetModuleSettingString(name, defaultValue.ToString());

        int intValue;
        if (!Int32.TryParse(raw, out intValue))
        {
            intValue = defaultValue;
        }

        if (intValue < minValue) intValue = minValue;
        if (intValue > maxValue) intValue = maxValue;

        return intValue;
    }

    protected string Encode(object value)
    {
        return Server.HtmlEncode(Convert.ToString(value));
    }

    protected string CommentBody(object value)
    {
        var encoded = Server.HtmlEncode(Convert.ToString(value));
        return encoded.Replace("\r\n", "<br />").Replace("\n", "<br />");
    }

    protected string CommentStatusCss(object value)
    {
        return Convert.ToBoolean(value) ? "jc-approved" : "jc-pending";
    }

    protected string CommentDepthCss(object value)
    {
        var depth = 0;

        if (value != null && value != DBNull.Value)
        {
            Int32.TryParse(Convert.ToString(value), out depth);
        }

        if (depth < 0) depth = 0;
        if (depth > 3) depth = 3;

        return "jc-depth-" + depth;
    }

    protected string CommentStatusText(object value)
    {
        return Convert.ToBoolean(value) ? "" : "Pending approval";
    }

    protected string FormatDate(object value)
    {
        if (value == null || value == DBNull.Value) return String.Empty;

        var utcDate = DateTime.SpecifyKind(Convert.ToDateTime(value), DateTimeKind.Utc);

        // Use the server's local time zone. If your DNN server runs UTC, this will remain UTC.
        var localDate = utcDate.ToLocalTime();

        return localDate.ToString("dd MMM yyyy, h:mm tt");
    }

    protected bool ShowLanguageFilterFlag(object value)
    {
        if (!CanModerateComments() || value == null || value == DBNull.Value)
        {
            return false;
        }

        bool flagged;
        return Boolean.TryParse(Convert.ToString(value), out flagged) && flagged;
    }

    protected string FormatEditedDate(object value)
    {
        if (value == null || value == DBNull.Value)
        {
            return String.Empty;
        }

        var editedUtc = DateTime.SpecifyKind(Convert.ToDateTime(value), DateTimeKind.Utc);
        return "Edited " + editedUtc.ToLocalTime().ToString("dd MMM yyyy, h:mm tt");
    }

    protected bool CanEditComment(object commentUserId, object createdOnDate)
    {
        if (!IsRegisteredCommentUser || commentUserId == null || commentUserId == DBNull.Value
            || createdOnDate == null || createdOnDate == DBNull.Value)
        {
            return false;
        }

        int ownerUserId;
        if (!Int32.TryParse(Convert.ToString(commentUserId), out ownerUserId) || ownerUserId != UserId)
        {
            return false;
        }

        var createdUtc = DateTime.SpecifyKind(Convert.ToDateTime(createdOnDate), DateTimeKind.Utc);
        return DateTime.UtcNow <= createdUtc.AddMinutes(RegisteredEditWindowMinutes);
    }

    private static string Truncate(string value, int maxLength)
    {
        if (String.IsNullOrEmpty(value)) return String.Empty;
        return value.Length <= maxLength ? value : value.Substring(0, maxLength);
    }

    protected string CommentAnchorId(object commentId)
    {
        int parsedCommentId;

        if (!Int32.TryParse(Convert.ToString(commentId), out parsedCommentId) || parsedCommentId <= 0)
        {
            return CommentAnchorPrefix + ModuleId + "-0";
        }

        return GetCommentAnchorId(parsedCommentId);
    }

    private string GetCommentAnchorId(int commentId)
    {
        return CommentAnchorPrefix + ModuleId + "-" + commentId;
    }

    private void QueuePostRedirectMessage(string message, bool success)
    {
        QueuePostRedirectMessage(message, success, null);
    }

    private void QueuePostRedirectMessage(string message, bool success, int? targetCommentId)
    {
        if (Session == null)
        {
            return;
        }

        Session[PostRedirectMessageSessionKey] = message ?? String.Empty;
        Session[PostRedirectSuccessSessionKey] = success.ToString();

        if (targetCommentId.HasValue && targetCommentId.Value > 0)
        {
            Session[PostRedirectTargetCommentSessionKey] = targetCommentId.Value.ToString();
        }
        else
        {
            Session.Remove(PostRedirectTargetCommentSessionKey);
        }
    }

    private void ShowPostCompletionMessageFromRedirect()
    {
        string message;
        bool success;
        int? targetCommentId;

        if (TryGetPostRedirectMessageFromQuery(out message, out success, out targetCommentId))
        {
            ShowMessage(message, success);
            ClearCommentEntryFields();
            RegisterClearCommentFormScript();

            if (targetCommentId.HasValue)
            {
                RegisterCommentTargetFocusScript(targetCommentId.Value);
            }

            RegisterCleanPostRedirectUrlScript(targetCommentId);
            return;
        }

        ShowQueuedPostRedirectMessage();
    }

    private bool TryGetPostRedirectMessageFromQuery(out string message, out bool success, out int? targetCommentId)
    {
        message = String.Empty;
        success = true;
        targetCommentId = null;

        if (Request == null || Request.QueryString == null)
        {
            return false;
        }

        var rawModuleId = Request.QueryString[PostRedirectModuleQueryKey];
        int queryModuleId;

        if (!Int32.TryParse(rawModuleId, out queryModuleId) || queryModuleId != ModuleId)
        {
            return false;
        }

        var statusCode = (Request.QueryString[PostRedirectStatusQueryKey] ?? String.Empty).Trim();

        if (String.IsNullOrWhiteSpace(statusCode))
        {
            return false;
        }

        message = GetPostRedirectStatusMessage(statusCode);

        if (String.IsNullOrWhiteSpace(message) || Session == null)
        {
            return false;
        }

        var rawQueuedMessage = Session[PostRedirectMessageSessionKey];

        // A completion query string is valid only for the first redirected request
        // that still has the matching one-time session message. This prevents a
        // refresh, logout, or copied URL from recreating an old success message.
        if (rawQueuedMessage == null)
        {
            return false;
        }

        var queuedMessage = Convert.ToString(rawQueuedMessage);
        var rawSuccess = Session[PostRedirectSuccessSessionKey];
        var rawQueuedTargetCommentId = Session[PostRedirectTargetCommentSessionKey];

        Session.Remove(PostRedirectMessageSessionKey);
        Session.Remove(PostRedirectSuccessSessionKey);
        Session.Remove(PostRedirectTargetCommentSessionKey);

        int queuedTargetCommentId;
        int queryTargetCommentId;
        var rawQueryTargetCommentId = Request.QueryString[PostRedirectCommentQueryKey];

        if (Int32.TryParse(Convert.ToString(rawQueuedTargetCommentId), out queuedTargetCommentId)
            && queuedTargetCommentId > 0
            && (String.IsNullOrWhiteSpace(rawQueryTargetCommentId)
                || (Int32.TryParse(rawQueryTargetCommentId, out queryTargetCommentId)
                    && queryTargetCommentId == queuedTargetCommentId))
            && IsCommentVisibleInCurrentScope(queuedTargetCommentId))
        {
            targetCommentId = queuedTargetCommentId;
        }

        if (!String.IsNullOrWhiteSpace(queuedMessage))
        {
            message = queuedMessage;
        }

        if (!Boolean.TryParse(Convert.ToString(rawSuccess), out success))
        {
            success = true;
        }

        return true;
    }

    private void ShowQueuedPostRedirectMessage()
    {
        if (Session == null)
        {
            return;
        }

        var rawMessage = Session[PostRedirectMessageSessionKey];

        if (rawMessage == null)
        {
            return;
        }

        var message = Convert.ToString(rawMessage);
        var rawSuccess = Session[PostRedirectSuccessSessionKey];
        var rawTargetCommentId = Session[PostRedirectTargetCommentSessionKey];

        Session.Remove(PostRedirectMessageSessionKey);
        Session.Remove(PostRedirectSuccessSessionKey);
        Session.Remove(PostRedirectTargetCommentSessionKey);

        if (String.IsNullOrWhiteSpace(message))
        {
            return;
        }

        bool success;
        if (!Boolean.TryParse(Convert.ToString(rawSuccess), out success))
        {
            success = true;
        }

        ShowMessage(message, success);

        int targetCommentId;
        if (Int32.TryParse(Convert.ToString(rawTargetCommentId), out targetCommentId)
            && targetCommentId > 0
            && IsCommentVisibleInCurrentScope(targetCommentId))
        {
            RegisterCommentTargetFocusScript(targetCommentId);
        }
    }

    private string GetPostRedirectStatusCode(bool isReply, bool isApproved)
    {
        if (isReply)
        {
            return isApproved ? "reply-posted" : "reply-pending";
        }

        return isApproved ? "comment-posted" : "comment-pending";
    }

    private string GetPostRedirectStatusMessage(string statusCode)
    {
        statusCode = (statusCode ?? String.Empty).Trim().ToLowerInvariant();

        switch (statusCode)
        {
            case "comment-posted":
                return "Your comment has been posted. You can refresh the page safely.";
            case "comment-pending":
                return "Your comment was received and is waiting for approval. You can refresh the page safely.";
            case "reply-posted":
                return "Your reply has been posted. You can refresh the page safely.";
            case "reply-pending":
                return "Your reply was received and is waiting for approval. You can refresh the page safely.";
            case "comment-edited":
                return "Your comment changes have been saved. You can refresh the page safely.";
            case "comment-edit-pending":
                return "Your comment changes were saved and are waiting for approval. You can refresh the page safely.";
            case "reply-edited":
                return "Your reply changes have been saved. You can refresh the page safely.";
            case "reply-edit-pending":
                return "Your reply changes were saved and are waiting for approval. You can refresh the page safely.";
            case "received":
                return "Your comment has been received. You can refresh the page safely.";
            case "comment-approved":
                return "Comment approved. You can refresh the page safely.";
            case "comment-deleted":
                return "Comment deleted. You can refresh the page safely.";
            default:
                return String.Empty;
        }
    }

    private bool IsCommentVisibleInCurrentScope(int commentId)
    {
        if (commentId <= 0)
        {
            return false;
        }

        using (var connection = new SqlConnection(ConnectionString))
        using (var command = connection.CreateCommand())
        {
            command.CommandText = @"
SELECT COUNT(1)
FROM " + CommentsTable + @"
WHERE CommentId = @CommentId
  AND PortalId = @PortalId
  AND TabId = @TabId
  AND ModuleId = @ModuleId
  AND IsDeleted = 0
  AND (IsApproved = 1 OR (@CurrentUserId > -1 AND UserId = @CurrentUserId));";

            command.Parameters.Add("@CommentId", SqlDbType.Int).Value = commentId;
            command.Parameters.Add("@PortalId", SqlDbType.Int).Value = PortalId;
            command.Parameters.Add("@TabId", SqlDbType.Int).Value = TabId;
            command.Parameters.Add("@ModuleId", SqlDbType.Int).Value = ModuleId;
            command.Parameters.Add("@CurrentUserId", SqlDbType.Int).Value = UserId;

            connection.Open();
            return Convert.ToInt32(command.ExecuteScalar()) > 0;
        }
    }

    private void ClearQueuedPostRedirectMessage()
    {
        if (Session == null)
        {
            return;
        }

        Session.Remove(PostRedirectMessageSessionKey);
        Session.Remove(PostRedirectSuccessSessionKey);
        Session.Remove(PostRedirectTargetCommentSessionKey);
    }

    private void RegisterCleanPostRedirectUrlScript(int? targetCommentId)
    {
        if (Page == null)
        {
            return;
        }

        string cleanUrl;

        try
        {
            cleanUrl = AppendRedirectAnchor(
                DotNetNuke.Common.Globals.NavigateURL(TabId, String.Empty),
                targetCommentId);
        }
        catch
        {
            cleanUrl = "#" + (targetCommentId.HasValue
                ? GetCommentAnchorId(targetCommentId.Value)
                : PostRedirectMessageAnchorId);
        }

        var script = @"
(function () {
    if (!window.history || !window.history.replaceState) { return; }

    try {
        window.history.replaceState(null, document.title, '"
            + HttpUtility.JavaScriptStringEncode(cleanUrl) + @"');
    } catch (e) { }
})();";

        RegisterStartupScript("JacarandaCommentsCleanPostRedirectUrl_" + ModuleId, script);
    }

    private bool TryRedirectAfterSuccessfulPost(string statusCode)
    {
        return TryRedirectAfterSuccessfulPost(statusCode, null);
    }

    private bool TryRedirectAfterSuccessfulPost(string statusCode, int? targetCommentId)
    {
        var redirectUrl = BuildPostRedirectUrl(statusCode, targetCommentId);

        if (String.IsNullOrWhiteSpace(redirectUrl) || Response == null)
        {
            return false;
        }

        try
        {
            Response.Redirect(redirectUrl, false);

            if (Context != null && Context.ApplicationInstance != null)
            {
                Context.ApplicationInstance.CompleteRequest();
            }

            return true;
        }
        catch
        {
            return false;
        }
    }

    private void RegisterPostSuccessRedirectScript(string statusCode)
    {
        if (Page == null)
        {
            return;
        }

        var redirectUrl = BuildPostRedirectUrl(statusCode);

        if (String.IsNullOrWhiteSpace(redirectUrl))
        {
            return;
        }

        var script = @"
(function () {
    var url = '" + HttpUtility.JavaScriptStringEncode(redirectUrl) + @"';

    function go() {
        try {
            window.location.replace(url);
        } catch (e) {
            window.location.href = url;
        }
    }

    window.setTimeout(go, 250);
})();";

        RegisterStartupScript("JacarandaCommentsPostSuccessRedirect_" + ModuleId, script);
    }

    private string BuildPostRedirectUrl(string statusCode)
    {
        return BuildPostRedirectUrl(statusCode, null);
    }

    private string BuildPostRedirectUrl(string statusCode, int? targetCommentId)
    {
        var safeStatusCode = (statusCode ?? String.Empty).Trim().ToLowerInvariant();

        if (String.IsNullOrWhiteSpace(safeStatusCode))
        {
            safeStatusCode = "received";
        }

        string redirectUrl;

        try
        {
            var redirectParameters = new List<string>
            {
                PostRedirectStatusQueryKey + "=" + HttpUtility.UrlEncode(safeStatusCode),
                PostRedirectModuleQueryKey + "=" + ModuleId.ToString()
            };

            if (targetCommentId.HasValue && targetCommentId.Value > 0)
            {
                redirectParameters.Add(
                    PostRedirectCommentQueryKey + "=" + targetCommentId.Value.ToString());
            }

            redirectUrl = DotNetNuke.Common.Globals.NavigateURL(
                TabId,
                String.Empty,
                redirectParameters.ToArray());
        }
        catch
        {
            redirectUrl = Request != null ? Request.RawUrl : String.Empty;

            if (!String.IsNullOrWhiteSpace(redirectUrl))
            {
                var hashIndex = redirectUrl.IndexOf('#');
                if (hashIndex >= 0)
                {
                    redirectUrl = redirectUrl.Substring(0, hashIndex);
                }

                var separator = redirectUrl.IndexOf('?') >= 0 ? "&" : "?";
                redirectUrl = redirectUrl + separator
                    + PostRedirectStatusQueryKey + "=" + HttpUtility.UrlEncode(safeStatusCode)
                    + "&" + PostRedirectModuleQueryKey + "=" + ModuleId.ToString();

                if (targetCommentId.HasValue && targetCommentId.Value > 0)
                {
                    redirectUrl += "&" + PostRedirectCommentQueryKey + "="
                        + targetCommentId.Value.ToString();
                }
            }
        }

        redirectUrl = AppendRedirectAnchor(redirectUrl, targetCommentId);

        return redirectUrl;
    }

    private string AppendRedirectAnchor(string redirectUrl, int? targetCommentId)
    {
        if (String.IsNullOrWhiteSpace(redirectUrl))
        {
            return redirectUrl;
        }

        var hashIndex = redirectUrl.IndexOf('#');
        if (hashIndex >= 0)
        {
            redirectUrl = redirectUrl.Substring(0, hashIndex);
        }

        var anchorId = targetCommentId.HasValue && targetCommentId.Value > 0
            ? GetCommentAnchorId(targetCommentId.Value)
            : PostRedirectMessageAnchorId;

        return redirectUrl + "#" + anchorId;
    }

    private void ShowMessage(string message, bool success)
    {
        ShowMessage(message, success, false);
    }

    private void ShowPostingValidationMessage(string message)
    {
        ShowMessage(message, false, true);
    }

    private void ShowMessage(string message, bool success, bool returnToCommentForm)
    {
        pnlMessage.Visible = true;
        pnlMessage.CssClass = success
            ? "jc-message jc-message-success jc-message-complete"
            : "jc-message jc-message-error";
        pnlMessage.Attributes["role"] = success ? "presentation" : "alert";
        pnlMessage.Attributes["aria-live"] = success ? "off" : "assertive";
        pnlMessage.Attributes["tabindex"] = "-1";

        var encodedMessage = Server.HtmlEncode(message);

        litMessage.Text = success
            ? "<strong>Process complete.</strong> " + encodedMessage
            : encodedMessage;

        pnlToast.Visible = success || returnToCommentForm;

        if (success)
        {
            pnlToast.CssClass = "jc-toast jc-toast-success";
            pnlToast.Attributes["role"] = "status";
            pnlToast.Attributes["aria-live"] = "polite";
            litToastTitle.Text = "Process complete";
            litToastMessage.Text = encodedMessage;
            RegisterToastScript();
        }
        else if (returnToCommentForm)
        {
            pnlToast.CssClass = "jc-toast jc-toast-error";
            pnlToast.Attributes["role"] = "alert";
            pnlToast.Attributes["aria-live"] = "assertive";
            litToastTitle.Text = "Please review your comment";
            litToastMessage.Text = encodedMessage;
            RegisterToastScript();
            RegisterCommentFormFocusScript();
        }
        else
        {
            RegisterMessageFocusScript();
        }
    }

    private void RegisterToastScript()
    {
        if (Page == null || pnlToast == null)
        {
            return;
        }

        var toastId = HttpUtility.JavaScriptStringEncode(pnlToast.ClientID);

        var script = @"
(function () {
    var toast = document.getElementById('" + toastId + @"');
    if (!toast || toast.getAttribute('data-jc-toast-ready') === 'true') { return; }

    toast.setAttribute('data-jc-toast-ready', 'true');

    var moduleRoot = null;
    if (toast.closest) {
        moduleRoot = toast.closest('.jacaranda-comments');
    }

    if (!moduleRoot) {
        var current = toast.parentNode;
        while (current && current !== document.body) {
            if ((' ' + current.className + ' ').indexOf(' jacaranda-comments ') >= 0) {
                moduleRoot = current;
                break;
            }
            current = current.parentNode;
        }
    }

    var closeButton = toast.querySelector('.jc-toast-close');
    var dismissed = false;
    var layoutQueued = false;
    var autoDismissTimer = null;

    function clamp(value, minimum, maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    function positionToast() {
        layoutQueued = false;
        if (dismissed || !moduleRoot) { return; }

        var moduleRect = moduleRoot.getBoundingClientRect();
        var viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
        var moduleWidth = moduleRoot.clientWidth || Math.max(0, moduleRect.width);
        var moduleHeight = moduleRoot.clientHeight || Math.max(0, moduleRect.height);
        var inset = 12;
        var availableWidth = Math.max(0, moduleWidth - (inset * 2));
        var toastWidth = Math.min(448, availableWidth);

        if (toastWidth <= 0) { return; }

        toast.style.width = toastWidth + 'px';
        toast.style.maxWidth = toastWidth + 'px';
        toast.style.left = Math.max(inset, moduleWidth - toastWidth - inset) + 'px';
        toast.style.right = 'auto';

        var maximumToastHeight = Math.max(120, Math.min(viewportHeight - (inset * 2), moduleHeight - (inset * 2)));
        toast.style.maxHeight = maximumToastHeight + 'px';

        var toastHeight = toast.offsetHeight;
        var visibleTop = Math.max(moduleRect.top, inset);
        var visibleBottom = Math.min(moduleRect.bottom, viewportHeight - inset);
        var viewportTarget = visibleBottom > visibleTop
            ? visibleTop + ((visibleBottom - visibleTop) / 2)
            : viewportHeight / 2;

        var topWithinModule = viewportTarget - moduleRect.top - (toastHeight / 2);
        var maximumTop = Math.max(inset, moduleHeight - toastHeight - inset);
        toast.style.top = clamp(topWithinModule, inset, maximumTop) + 'px';
        toast.classList.add('jc-toast-positioned');
    }

    function queuePositionToast() {
        if (dismissed || layoutQueued) { return; }
        layoutQueued = true;

        if (window.requestAnimationFrame) {
            window.requestAnimationFrame(positionToast);
        } else {
            window.setTimeout(positionToast, 16);
        }
    }

    function removePositionListeners() {
        if (window.removeEventListener) {
            window.removeEventListener('resize', queuePositionToast);
            window.removeEventListener('scroll', queuePositionToast);
        }
    }

    function dismissToast(event) {
        if (event && event.preventDefault) { event.preventDefault(); }
        if (dismissed) { return false; }

        dismissed = true;

        if (autoDismissTimer) {
            window.clearTimeout(autoDismissTimer);
            autoDismissTimer = null;
        }

        removePositionListeners();
        toast.classList.add('jc-toast-hidden');

        window.setTimeout(function () {
            toast.style.display = 'none';
        }, 250);

        return false;
    }

    if (closeButton) {
        closeButton.onclick = dismissToast;
    }

    if (window.addEventListener) {
        window.addEventListener('resize', queuePositionToast);
        window.addEventListener('scroll', queuePositionToast, { passive: true });
        window.addEventListener('load', queuePositionToast);
    }

    queuePositionToast();
    window.setTimeout(queuePositionToast, 150);
    window.setTimeout(queuePositionToast, 500);
    autoDismissTimer = window.setTimeout(dismissToast, 12000);
})();";

        RegisterStartupScript("JacarandaCommentsToast_" + ModuleId, script);
    }

    private void RegisterMessageFocusScript()
    {
        RegisterScrollAndFocusScript(
            pnlMessage != null ? pnlMessage.ClientID : String.Empty,
            pnlMessage != null ? pnlMessage.ClientID : String.Empty,
            "Message");
    }

    private void RegisterCommentFormFocusScript()
    {
        RegisterScrollAndFocusScript(
            pnlCommentForm != null ? pnlCommentForm.ClientID : String.Empty,
            txtComment != null ? txtComment.ClientID : String.Empty,
            "CommentForm");
    }

    private void RegisterCommentTargetFocusScript(int commentId)
    {
        if (commentId <= 0)
        {
            return;
        }

        var anchorId = GetCommentAnchorId(commentId);
        RegisterScrollAndFocusScript(anchorId, anchorId, "PublishedComment_" + commentId);
    }

    private void RegisterScrollAndFocusScript(string targetClientId, string focusClientId, string keySuffix)
    {
        if (Page == null || String.IsNullOrWhiteSpace(targetClientId))
        {
            return;
        }

        var targetId = HttpUtility.JavaScriptStringEncode(targetClientId);
        var focusId = HttpUtility.JavaScriptStringEncode(focusClientId ?? String.Empty);

        var script = @"
(function () {
    var hasFocused = false;
    var attempts = 0;
    var maximumAttempts = 60;
    var retryDelay = 100;
    var settleDelays = [0, 200, 600, 1200, 2200];

    function positionTarget() {
        var target = document.getElementById('" + targetId + @"');
        var focusTarget = document.getElementById('" + focusId + @"');

        if (!target) { return false; }

        try {
            target.scrollIntoView({ behavior: 'auto', block: 'center' });
        } catch (e) {
            try { target.scrollIntoView(); } catch (ignoreScroll) { }
        }

        if (!hasFocused && focusTarget) {
            try {
                focusTarget.focus({ preventScroll: true });
            } catch (e) {
                try { focusTarget.focus(); } catch (ignoreFocus) { }
            }

            hasFocused = true;
        }

        return true;
    }

    function settleTarget() {
        for (var i = 0; i < settleDelays.length; i++) {
            window.setTimeout(positionTarget, settleDelays[i]);
        }
    }

    function findTarget() {
        attempts += 1;

        if (positionTarget()) {
            settleTarget();
            return;
        }

        if (attempts < maximumAttempts) {
            window.setTimeout(findTarget, retryDelay);
        }
    }

    function startTargeting() {
        attempts = 0;
        findTarget();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startTargeting);
    } else {
        startTargeting();
    }

    if (window.addEventListener) {
        window.addEventListener('load', startTargeting);
    }
})();";

        RegisterStartupScript(
            "JacarandaCommentsFocus" + keySuffix + "_" + ModuleId,
            script);
    }
</script>

<div id="<%= PostRedirectMessageAnchorId %>" class="jacaranda-comments">
    <div class="jc-header">
        <h2>Comments</h2>
        <span class="jc-count"><asp:Literal ID="litCount" runat="server" /></span>
    </div>

    <asp:Panel ID="pnlMessage"
               runat="server"
               Visible="false"
               CssClass="jc-message">
        <asp:Literal ID="litMessage" runat="server" />
    </asp:Panel>

    <asp:Panel ID="pnlToast"
               runat="server"
               Visible="false"
               CssClass="jc-toast"
               role="status"
               aria-live="polite"
               aria-atomic="true">
        <span class="jc-toast-icon" aria-hidden="true"></span>
        <div class="jc-toast-content">
            <strong class="jc-toast-title"><asp:Literal ID="litToastTitle" runat="server" /></strong>
            <span class="jc-toast-message"><asp:Literal ID="litToastMessage" runat="server" /></span>
        </div>
        <button type="button"
                class="jc-toast-close"
                aria-label="Close notification"
                onclick="var toast=this.parentNode;if(toast){toast.classList.add('jc-toast-hidden');window.setTimeout(function(){toast.style.display='none';},250);}return false;">&times;</button>
    </asp:Panel>

    <asp:Panel ID="pnlNoComments" runat="server" CssClass="jc-empty" Visible="false">
        No comments yet.
    </asp:Panel>

    <asp:Repeater ID="rptComments" runat="server" OnItemCommand="rptComments_ItemCommand">
        <ItemTemplate>
            <article id='<%# CommentAnchorId(Eval("CommentId")) %>'
                     tabindex="-1"
                     class='jc-comment <%# CommentStatusCss(Eval("IsApproved")) %> <%# CommentDepthCss(Eval("Depth")) %>'>
                <header class="jc-comment-meta">
                    <strong class="jc-comment-author"><%# Encode(Eval("DisplayName")) %></strong>
                    <span class="jc-comment-date"><%# FormatDate(Eval("CreatedOnDate")) %></span>
                    <span class="jc-comment-edited"><%# FormatEditedDate(Eval("EditedOnDate")) %></span>
                    <span class="jc-comment-status"><%# CommentStatusText(Eval("IsApproved")) %></span>
                    <asp:Label ID="lblLanguageFilterFlag"
                               runat="server"
                               CssClass="jc-language-flag"
                               Text="Language filter"
                               ToolTip="This submission matched the private module language filter and requires moderator review."
                               Visible='<%# ShowLanguageFilterFlag(Eval("IsLanguageFlagged")) %>' />
                </header>

                <div class="jc-comment-body">
                    <%# CommentBody(Eval("CommentText")) %>
                </div>

                <div class="jc-comment-actions">
                    <asp:LinkButton ID="btnReply"
                                    runat="server"
                                    CssClass="jc-action jc-reply"
                                    CommandName="ReplyTo"
                                    CommandArgument='<%# Eval("CommentId") %>'
                                    Visible='<%# CanPostComments %>'>
                        Reply
                    </asp:LinkButton>

                    <asp:LinkButton ID="btnEdit"
                                    runat="server"
                                    CssClass="jc-action jc-edit"
                                    CommandName="EditComment"
                                    CommandArgument='<%# Eval("CommentId") %>'
                                    CausesValidation="false"
                                    ToolTip="Edit your own comment within 15 minutes of posting"
                                    Visible='<%# CanEditComment(Eval("UserId"), Eval("CreatedOnDate")) %>'>
                        Edit
                    </asp:LinkButton>

                    <asp:Panel ID="pnlModeration" runat="server" CssClass="jc-moderation" Visible='<%# CanModerateComments() %>'>
                        <asp:LinkButton ID="btnApprove"
                                        runat="server"
                                        CssClass="jc-action"
                                        CommandName="Approve"
                                        CommandArgument='<%# Eval("CommentId") %>'
                                        Visible='<%# !Convert.ToBoolean(Eval("IsApproved")) %>'>
                            Approve
                        </asp:LinkButton>

                        <asp:LinkButton ID="btnDelete"
                                        runat="server"
                                        CssClass="jc-action jc-action-danger"
                                        CommandName="Delete"
                                        CommandArgument='<%# Eval("CommentId") %>'
                                        OnClientClick="return confirm('Delete this comment and its replies from view?');">
                            Delete
                        </asp:LinkButton>
                    </asp:Panel>
                </div>
            </article>
        </ItemTemplate>
    </asp:Repeater>

    <asp:Panel ID="pnlLoginRequired" runat="server" CssClass="jc-login-required">
        Please sign in to leave a comment or reply. Guest commenting is currently switched off for this module.
    </asp:Panel>

    <asp:Panel ID="pnlCommentForm" runat="server" CssClass="jc-form">
        <h3><asp:Literal ID="litFormTitle" runat="server" /></h3>

        <asp:HiddenField ID="hdnSecurityToken" runat="server" />
        <asp:HiddenField ID="hdnParentCommentId" runat="server" />
        <asp:HiddenField ID="hdnEditCommentId" runat="server" />

        <asp:Panel ID="pnlReplyContext" runat="server" CssClass="jc-reply-context" Visible="false">
            <asp:Literal ID="litReplyContext" runat="server" />
            <asp:LinkButton ID="btnCancelReply"
                            runat="server"
                            CssClass="jc-cancel-reply"
                            OnClick="btnCancelReply_Click"
                            CausesValidation="false">
                Cancel reply
            </asp:LinkButton>
        </asp:Panel>

        <asp:Panel ID="pnlEditContext" runat="server" CssClass="jc-edit-context" Visible="false">
            <asp:Literal ID="litEditContext" runat="server" />
            <asp:LinkButton ID="btnCancelEdit"
                            runat="server"
                            CssClass="jc-cancel-edit"
                            OnClick="btnCancelEdit_Click"
                            CausesValidation="false">
                Cancel editing
            </asp:LinkButton>
        </asp:Panel>

        <div class="jc-field">
            <asp:Label ID="lblDisplayName" runat="server" AssociatedControlID="txtDisplayName" Text="Name shown" />
            <asp:TextBox ID="txtDisplayName" runat="server" MaxLength="100" CssClass="jc-input" />
        </div>

        <asp:Panel ID="pnlGuestEmail" runat="server" CssClass="jc-field jc-guest-email" Visible="false">
            <asp:Label ID="lblGuestEmail" runat="server" AssociatedControlID="txtGuestEmail" Text="Email address (private)" />
            <asp:TextBox ID="txtGuestEmail"
                         runat="server"
                         MaxLength="254"
                         TextMode="Email"
                         CssClass="jc-input" />
            <p class="jc-field-help">Your email is encrypted before storage and is never displayed with your comment.</p>
        </asp:Panel>

        <asp:Panel ID="pnlGuestNotice" runat="server" CssClass="jc-guest-notice" Visible="false">
            <strong>Guest posting:</strong> every submission is reviewed before publication and cannot be edited after it is sent. Register or sign in before posting to receive a 15-minute editing window.
        </asp:Panel>

        <div class="jc-field jc-hp" aria-hidden="true">
            <asp:Label ID="lblWebsite" runat="server" AssociatedControlID="txtWebsite" Text="Website" />
            <asp:TextBox ID="txtWebsite" runat="server" CssClass="jc-input" TabIndex="-1" autocomplete="off" />
        </div>

        <div class="jc-field">
            <asp:Label ID="lblComment" runat="server" AssociatedControlID="txtComment" Text="Comment" />
            <asp:TextBox ID="txtComment"
                         runat="server"
                         TextMode="MultiLine"
                         Rows="5"
                         CssClass="jc-textarea"
                         autocomplete="off" />
            <p id="commentLengthHelp" runat="server" class="jc-comment-length">
                <asp:Literal ID="litCommentLimit" runat="server" />
                <span id="spnCommentCounter" runat="server" class="jc-character-counter"></span>
            </p>
        </div>

        <asp:Panel ID="pnlCaptcha" runat="server" CssClass="jc-field jc-captcha" Visible="false">
            <asp:Label ID="lblCaptcha" runat="server" AssociatedControlID="txtCaptcha" Text="Anti-spam question" />
            <div class="jc-captcha-row">
                <span class="jc-captcha-question"><asp:Literal ID="litCaptchaQuestion" runat="server" /></span>
                <asp:TextBox ID="txtCaptcha" runat="server" MaxLength="5" CssClass="jc-input jc-captcha-input" autocomplete="off" />
            </div>
        </asp:Panel>

        <asp:Button ID="btnSubmit"
                    runat="server"
                    Text="Post comment"
                    CssClass="jc-submit"
                    OnClick="btnSubmit_Click" />

        <p class="jc-note"><asp:Literal ID="litModerationNote" runat="server" /></p>
    </asp:Panel>
</div>
