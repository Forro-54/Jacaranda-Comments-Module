Jacaranda Comments 01.00.07

This release fixes the case where the comment textarea clears immediately after posting,
but the browser restores the old text after refreshing the page.

The successful post path now uses Post/Redirect/Get:
1. Save the comment or reply.
2. Queue the success/pending message in the user's session.
3. Redirect back to the same page using a GET request.
4. Display the queued message and bind the fresh comments list.

This prevents browser refresh from replaying or restoring the previous POST body.

No database schema changes are required.
