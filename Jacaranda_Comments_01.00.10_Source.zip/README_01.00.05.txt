Jacaranda Comments 01.00.05

Security hardening release after source review.

Highlights:
- No classic SQL injection path was found in comment text, display names, comment IDs, reply IDs, or settings; SQL values are parameterized.
- Adds a per-session security token check to post/comment/reply/moderation actions.
- Locks saved display names to the logged-in DNN user's profile display name/username.
- Hardens DNN SQL identifier construction for database owner/object qualifier values.
- Hardens notification recipient validation and email subject handling.

No database schema changes are required.
