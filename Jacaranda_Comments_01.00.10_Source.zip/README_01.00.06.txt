Jacaranda Comments 01.00.06

This is a small UI cleanup release.

Changes:
- Clears the add-comment/reply text area after a comment or reply is successfully saved.
- Clears the CAPTCHA answer and hidden honeypot field after successful form handling.
- Registers a small client-side cleanup script after successful submission, so the browser does not keep the old posted text in the visible field.
- No SQL schema changes are required.

Install:
- Install over 01.00.05 using DNN's Extensions installer.
- If the old ASCX appears to remain loaded, clear DNN cache or recycle the application pool.
