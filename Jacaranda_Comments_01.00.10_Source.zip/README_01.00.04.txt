Jacaranda Comments 01.00.04

Hotfix release for DNN runtime compile error CS0104.

Change:
- View.ascx now calls DotNetNuke.Common.Globals.NavigateURL(TabId) instead of Globals.NavigateURL(TabId).

This is a code-only hotfix. No database schema changes are required.
