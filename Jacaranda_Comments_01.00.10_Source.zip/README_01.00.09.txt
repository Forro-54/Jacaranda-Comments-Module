Jacaranda Comments 01.00.09

Purpose
-------
This release fixes the post-success user experience where the posted text could remain in the Add Comment box and the process-complete message might not appear.

Changes
-------
- Shows a process-complete message immediately after a successful comment/reply save.
- Registers a clean client-side redirect back to the page using jcposted/jcmid query parameters.
- Shows the same completion message after the clean GET redirect.
- Clears the comment, CAPTCHA, and honeypot fields both before and after the redirect.
- Adds autocomplete="off" to the Add Comment textarea.
- Keeps the existing moderation, CAPTCHA, notification, and rate-limit features.
- No database schema changes.

Install
-------
Install Jacaranda_Comments_01.00.09_Install.zip over the previous version through DNN's Extensions installer.
If the old behavior remains, recycle the application pool or clear DNN cache so View.ascx recompiles.
