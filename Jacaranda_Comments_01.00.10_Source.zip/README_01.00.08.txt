Jacaranda Comments 01.00.08

This release improves the poster confirmation after a successful comment or reply.

Changes:
- Adds a clearer “Process complete” success message after comment/reply submission.
- Carries the confirmation through the existing Post/Redirect/Get flow.
- Redirects back to the page with an anchor to the message area.
- Scrolls/focuses the confirmation message when possible so the poster can see that the process is complete.
- Keeps validation errors unchanged so users do not lose their text when a submission fails.
- No database schema changes are required.

Install:
- Install this ZIP over 01.00.07 using DNN's Extensions installer.
- If the old behavior remains, clear DNN cache or recycle the app pool so View.ascx recompiles.
